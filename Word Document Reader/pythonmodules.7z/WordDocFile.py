from docx import Document
import pandas as pandas
from docx.shared import Inches
from docx.enum.style import WD_STYLE_TYPE
from tkinter import messagebox, Frame, font
# from processWordDoc import printDocumentProperties

import sys

class WordDocFile:

    document = Document()

    def __init__(self, wordDoc):
        self.document = Document(wordDoc)

    def printDocumentProperties(self):
        print("--------------------- Document Properties Start ----------------------------")
        print("document.inline_shapes count : ", str(len(self.document.inline_shapes)))
        print("document.paragraphs count : ", str(len(self.document.paragraphs)))
        print("document.sections count : ", str(len(self.document.sections)))
        print("document.settings : ", self.document.settings)
        print("document.settings.element  : ", self.document.settings.element)
        print("document.settings.odd_and_even_pages_header_footer  : ",
              self.document.settings.odd_and_even_pages_header_footer)
        print("document.styles count : ", str(len(self.document.styles)))
        print("document.tables count : ", str(len(self.document.tables)))
        print("----------------------- Document Properties Start --------------------------")

    def printDocumentPropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # messagebox.showinfo("document", self.document)
        self.printDocumentProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printDocumentCoreProperties(self):
        print("--------------------- Document Core Properties ----------------------------")
        core_properties = self.document.core_properties
        print("core_properties.author : ", core_properties.author)
        print("core_properties.category : ", core_properties.category)
        print("core_properties.comments : ", core_properties.comments)
        print("core_properties.content_status : ", core_properties.content_status)
        print("core_properties.created : ", core_properties.created)
        print("core_properties.identifier : ", core_properties.identifier)
        print("core_properties.keywords : ", core_properties.keywords)
        print("core_properties.language : ", core_properties.language)
        print("core_properties.last_modified_by : ", core_properties.last_modified_by)
        print("core_properties.last_printed : ", core_properties.last_printed)
        print("core_properties.modified : ", core_properties.modified)
        print("core_properties.revision : ", core_properties.revision)
        print("core_properties.subject : ", core_properties.subject)
        print("core_properties.title : ", core_properties.title)
        print("core_properties.version : ", core_properties.version)
        print("---------------------------------------------------------------------------")

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printDocumentCorePropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # redirectOutputToFile
        self.printDocumentCoreProperties()
        # redirectOutputToScreen
        # data = readOutputFile
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printDocumentInlineShapeProperties(self):
        print("--------------------- Document InlineShape Properties ----------------------------")
        print("document.inline_shapes count : ", str(len(self.document.inline_shapes)) )
        intCount = -1
        for shp in self.document.inline_shapes:
            print("\t------------------------------------------------------")
            intCount += 1
            print("\tshape {} : ".format(intCount))
            print("\tshape.height count : ", shp.height)
            print("\tshape.type count : ", shp.type)
            print("\tshape.width count : ", shp.width)
            print("\t------------------------------------------------------")
        print("----------------------------------------------------------------------------------------")

    def printDocumentInlineShapePropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printDocumentInlineShapeProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printDocumentParagraphsProperties(self):
        print("--------------------- Document Paragraphs Properties ----------------------------")
        paras = self.document.paragraphs
        print("\tParagraphs Count : " , len(paras))
        paraCount = 0

        for para in self.document.paragraphs:
            paraCount += 1
            print("")
            print("\t=======================================================")
            print("\tParagraph[{}]".format(str(paraCount)) + " : ")
            print("\t=======================================================")
            print("\tParagraph[{}]".format(str(paraCount)) + " Text : ", para.text)
            print("\tParagraph[{}]".format(str(paraCount)) + " alignment : ", para.alignment)

            print("\t========= paragraph_format[{}] Start ==========".format(paraCount))
            pf = para.paragraph_format
            print("\tparagraph_format.alignment : ", pf.alignment)
            print("\tparagraph_format.first_line_indent : ", pf.first_line_indent)
            print("\tparagraph_format.keep_together : ", pf.keep_together)
            print("\tparagraph_format.keep_with_next : ", pf.keep_with_next)
            print("\tparagraph_format.left_indent : ", pf.left_indent)
            print("\tparagraph_format.line_spacing : ", pf.line_spacing)
            print("\tparagraph_format.line_spacing_rule : ", pf.line_spacing_rule)
            print("\tparagraph_format.page_break_before : ", pf.page_break_before)
            print("\tparagraph_format.right_indent : ", pf.right_indent)
            print("\tparagraph_format.space_after : ", pf.space_after)
            print("\tparagraph_format.space_before : ", pf.space_before)
            print("\tparagraph_format.tab_stops : ", pf.tab_stops)
            print("\tparagraph_format.widow_control : ", pf.widow_control)

            print("\tparagraph_format.tab_stops count : ",  str(len(pf.tab_stops)))
            tsCount = -1
            for ts in pf.tab_stops:
                tsCount += 1
                print("\tparagraph_format.tab_stop [{}]: ".format(tsCount))
                print("\tparagraph_format.tab_stop.alignment: ", ts.alignment)
                print("\tparagraph_format.tab_stop.leader: ", ts.leader)
                print("\tparagraph_format.tab_stop.position: ", ts.position)

            print("\t========= paragraph_format[{}] End ==========".format(paraCount))
            print("")
            print("\t========= Paragraph[{}] Runs Start ==========".format(paraCount))
            print("\tParagraphs[{}].runs count :".format(paraCount), len(para.runs))
            len(para.runs)
            runCount = -1
            for run in para.runs:
                runCount += 1
                print("\t=============================================")
                print("\tParagraphs.run[" + str(runCount) + "] Start : ")
                print("\t=============================================")
                print("\trun.text : ", run.text)
                print("\trun.bold : ", run.bold)
                print("\trun.italic : ", run.italic)
                print("\trun.font : ", run.font)
                print("\t\trun.font.all_caps : ", run.font.all_caps)
                print("\t\trun.font.bold : ", run.font.bold)
                print("\t\trun.font.color.rgb : ", run.font.color.rgb)
                print("\t\trun.font.color.theme_color : ", run.font.color.theme_color)
                print("\t\trun.font.color.type : ", run.font.color.type)

                print("\t\trun.font.complex_script : ", run.font.complex_script)
                print("\t\trun.font.cs_bold : ", run.font.cs_bold)
                print("\t\trun.font.cs_italic : ", run.font.cs_italic)
                print("\t\trun.font.double_strike : ", run.font.double_strike)
                print("\t\trun.font.emboss : ", run.font.emboss)
                print("\t\trun.font.hidden : ", run.font.hidden)
                print("\t\trun.font.highlight_color : ", run.font.highlight_color)
                print("\t\trun.font.imprint : ", run.font.imprint)
                print("\t\trun.font.italic : ", run.font.italic)
                print("\t\trun.font.math : ", run.font.math)
                print("\t\trun.font.name : ", run.font.name)
                print("\t\trun.font.no_proof : ", run.font.no_proof)
                print("\t\trun.font.outline : ", run.font.outline)
                print("\t\trun.font.rtl : ", run.font.rtl)
                print("\t\trun.font.shadow : ", run.font.shadow)
                print("\t\trun.font.size : ", run.font.size)
                print("\t\trun.font.small_caps : ", run.font.small_caps)
                print("\t\trun.font.snap_to_grid : ", run.font.snap_to_grid)
                print("\t\trun.font.spec_vanish : ", run.font.spec_vanish)
                print("\t\trun.font.strike : ", run.font.strike)
                print("\t\trun.font.subscript : ", run.font.subscript)
                print("\t\trun.font.superscript : ", run.font.superscript)
                print("\t\trun.font.underline : ", run.font.underline)
                print("\t\trun.font.web_hidden : ", run.font.web_hidden)
                print("\trun.style : ", run.style)
                print("\t=============================================")
                print("\tParagraphs.run[" + str(runCount) + "] End : ")
                print("\t=============================================")
            print("")
            print("\t========= Paragraph[{}] Runs End   ==========".format(paraCount))
        print("-------------------------------------------------------------------------------")

    def printDocumentParagraphsPropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # redirectOutputToFile
        self.printDocumentParagraphsProperties()
        # redirectOutputToScreen
        # data = readOutputFile
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printSectionProperties(self):
        print("--------------------- Document Section Properties ----------------------------")
        sections = self.document.sections
        print("Number of Sections : ",  len(self.document.sections))

        sectionCount = 0
        for section in self.document.sections:
            sectionCount += 1
            print("\t=============== section [{}] ".format(sectionCount) , " Start ===============")
            print("\tsection [{}] ".format(sectionCount), " : ", section )
            print("\tsection.bottom_margin : ", section.bottom_margin)
            print("\tsection.bottom_margin.inches : ", section.bottom_margin.inches)
            print("\tsection.different_first_page_header_footer : ", section.different_first_page_header_footer)
            print("\tsection.even_page_footer.is_linked_to_previous : ", section.even_page_footer.is_linked_to_previous)
            print("\tsection.even_page_footer.paragraphs Count : ", len(section.even_page_footer.paragraphs))
            print("\tsection.even_page_footer.tables Count : ", len(section.even_page_footer.tables))
            print("\tsection.even_page_header.is_linked_to_previous : ", section.even_page_header.is_linked_to_previous)
            print("\tsection.even_page_header.paragraphs Count : ", len(section.even_page_header.paragraphs))
            print("\tsection.even_page_header.tables Count : ", len(section.even_page_header.tables))
            print("\tsection.first_page_footer.is_linked_to_previous : ", section.first_page_footer.is_linked_to_previous)
            print("\tsection.first_page_footer.paragraphs Count : ", len(section.first_page_footer.paragraphs))
            print("\tsection.first_page_footer.tables Count : ", len(section.first_page_footer.tables))
            print("\tsection.first_page_header.is_linked_to_previous : ", section.first_page_header.is_linked_to_previous)
            print("\tsection.first_page_header.paragraphs Count : ", len(section.first_page_header.paragraphs))
            print("\tsection.first_page_header.tables Count : ", len(section.first_page_header.tables))
            print("\tsection.footer.is_linked_to_previous : ", section.footer.is_linked_to_previous)
            print("\tsection.footer.paragraphs Count : ", len(section.footer.paragraphs))
            print("\tsection.footer.tables Count : ", len(section.footer.tables))
            print("\tsection.footer_distance : ", section.footer_distance)
            print("\tsection.footer_distance.inches : ", section.footer_distance.inches)
            print("\tsection.gutter : ", section.gutter)
            print("\tsection.gutter.inches : ", section.gutter.inches)
            print("\tsection.header.is_linked_to_previous : ", section.header.is_linked_to_previous)
            print("\tsection.header.paragraphs Count : ", len(section.header.paragraphs))
            print("\tsection.header.tables Count : ", len(section.header.tables))
            print("\tsection.header_distance : ", section.header_distance)
            print("\tsection.footer_distance.inches : ", section.header_distance.inches)
            print("\tsection.left_margin : ", section.left_margin)
            print("\tsection.left_margin.inches : ", section.left_margin.inches)
            print("\tsection.orientation : ", section.orientation)
            print("\tsection.page_height : ", section.page_height)
            print("\tsection.page_width : ", section.page_width)
            print("\tsection.right_margin : ", section.right_margin)
            print("\tsection.right_margin.inches : ", section.right_margin.inches )
            print("\tsection.start_type : ", section.start_type)
            print("\tsection.top_margin : ", section.top_margin)
            print("\tsection.top_margin.inches : ", section.top_margin.inches)
            print("\t=============== section [{}] ".format(sectionCount), " End ===============")
            print("")
        print("------------------------------------------------------------------------------")

    def printSectionPropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printSectionProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printDocumentSettingsProperties(self):
        print("--------------------- Document Settings Properties ----------------------------")
        settings = self.document.settings
        print("documnent.settings : ", settings)
        print("settings.element  : ", settings.element)
        print("settings.odd_and_even_pages_header_footer : ", settings.odd_and_even_pages_header_footer)
        print("-------------------------------------------------------------------------------")

    def printDocumentSettingsPropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printDocumentSettingsProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printDocumentTableProperties(self):
        print("--------------------- Document Table Properties ----------------------------")
        tbls = self.document.tables
        print("Document Table Count : ", len(tbls))
        print("       ------------------ Printing All Cells Row-wise in Table (table.rows() ---------------------------")
        for tbl in tbls:
            iRow = -1
            for row in tbl.rows:
                iRow += 1
                print("Row " + str(iRow) + " --> ", end="\t")
                for cell in row.cells:
                    print(cell.text, end="\t|\t")
                print("")
        print("       --------------------------------------------------------------------------")
        for tbl in tbls:
            print("Table alignment : ", tbl.alignment)
            print("Table autofit : ", tbl.autofit)
            print("Table table_direction : ", tbl.table_direction)
            print("Table style : ", tbl.style)
        print("")
        print("")
        print("       ---------  cell(row_idx, col_idx) :  Printing row-wise Cells in Table ( tbl.cell(iRow, jCol) ) ---------------------------")
        for tbl in tbls:
            iRow = -1
            for row in tbl.rows:
                iRow += 1
                jCol = -1
                print("Row " + str(iRow) + "  : ", end=" --> ")
                for col in tbl.columns:
                    jCol += 1
                    print(tbl.cell(iRow, jCol).text, end="\t | \t")
                print("")
        print("       --------------------------------------------------------------------------")
        print("       --------- columns(), column,  and column_cells(column_idx) : Printing Column-wise Cells in Table ( column_cells(column_idx) ) ---------------------------")
        for tbl in tbls:
            iCol = -1
            for col in tbl.columns:
                iCol += 1
                print("Column " + str(iCol) + "  : ", end=" --> ")
                print("Column cell count " + str(len(col.cells)), end="\t|\t")
                print("Column width " + str(col.width))
                for cell in tbl.column_cells(iCol):
                    print(cell.text, end="\t | \t")
                print("")
        print("       --------------------------------------------------------------------------")
        print(" ")
        print("       --------- rows() and row_cells(row_idx) : Printing Row-wise Cells in Table ( row_cells(row_idx) ) ---------------------------")
        for tbl in tbls:
            iRow = -1
            for row in tbl.rows:
                iRow += 1
                print("Row " + str(iRow) + "  : ", end=" --> ")
                for cell in tbl.row_cells(iRow):
                    print(cell.text, end="\t | \t")
                print("")
        print("       --------------------------------------------------------------------------")
        print(" ")
        print(" ")
        print("       ------------- Processing cell(), row, rows, cells object  ----------------------------------")
        for tbl in tbls:
            for row in tbl.rows:
                print("Row =======> " + str(row), end="\t|\t")
                print("Row cells Count : " + str(len(row.cells)), end="\t|\t")
                print("Row Height : " + str(row.height), end="\t|\t")
                print("Row height_rule : " + str(row.height_rule))
                for cell in row.cells:
                    # print("cell Text : " + cell.text + "\tcell.paragraphs : " + str(len(cell.paragraphs)) + "\tcell.tables : " + str(len(cell.tables) )+ "\tcell.vertical_alignment : " + cell.vertical_alignment + "\tcell.width : " + cell.width)
                    print("cell Text : " + cell.text, end="\t|\t")
                    print("\tcell.paragraphs : " + str(len(cell.paragraphs)), end="\t|\t")
                    print("\tcell.tables : " + str(len(cell.tables)), end="\t|\t")
                    print("\tcell.vertical_alignment : " + str(cell.vertical_alignment), end="\t|\t")
                    print("\tcell.width : " + str(cell.width))
        print("       ---------s-----------------------------------------------------------------")
        print(" ")
        print(" ")
        print("       ------------------ Printing DataFrame using Pandas ------------------------")

        data = []
        keys = None

        for tbl in tbls:
            for i, row in enumerate(tbl.rows):
                text = (cell.text for cell in row.cells)
                if i == 0:
                    keys = tuple(text)
                    continue
                row_data = dict(zip(keys, text))
                data.append(row_data)
                print(data)
        df = pandas.DataFrame(data)
        print(df)
        print("       ---------------------------------------------------------------------------")
        print(" ")
        print("----------------------------------------------------------------------------")

    def printDocumentTablePropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printDocumentTableProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    # Empty the Selected Property Entry box
    def printDocumentNonePropertiesStdout(self):
        return ""

    def printDocumentStyleProperties(self):
        print("--------------------- Document Styles Properties ----------------------------")
        styles = self.document.styles
        print("Document Styles Count : ", len(styles))
        print("-----------------------------------------------------------------------------")

    def printDocumentStylePropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printDocumentStyleProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data


    def getDocumentText(self):
        print("--------------------- Reading Text in Document ----------------------------")
        fullText = []
        for para in self.document.paragraphs:
            fullText.append(para.text)
        docText = '\n'.join(fullText)
        return docText

    # Returns list of Paragraphs in the Word Document
    def getParagraphList(self):
        print("--------------------- Creating list of Paragraphs in Document ----------------------------")
        paraIndexList = []
        paraTextList = []
        paraRunList = []
        paraCount = 0
        print("Number of paragraphs: ", len(self.document.paragraphs))
        for para in self.document.paragraphs:
            paraCount += 1
            runCount = 0
            currRuns = {}
            currRunList = []
            currRunDetails = []
            for run in para.runs:
                runCount += 1
                currRunDict = {}
                print("Para:{0}, Run:{1}".format(paraCount,  runCount))
                print("text:{0},\nitalic:{1},\nbold:{2},\nfont.name:{3},\nfont.color:{4},\nfont.size:{5}".format(run.text, run.italic, run.bold, run.font.name, run.font.color.rgb, run.font.size))
                currRunList.append(runCount)

                currRunDict["text"] = run.text
                currRunDict["italic"] = run.italic
                currRunDict["bold"] = run.bold
                currRunDict["font.name"] = run.font.name
                currRunDict["font.color"] = run.font.color.rgb
                currRunDict["font.highlight_color"] = run.font.highlight_color
                currRunDict["font.size"] = run.font.size

                currRunDetails.append(currRunDict)
                #  working .. currRunDetails.append("text:{0}, italic:{1}, bold:{2}, font.name:{3}, font.color:{4}, font.size:{5}".format(run.text, run.italic, run.bold, run.font.name, run.font.color.rgb, run.font.size))
                # removed currRunDetails.append(" ""text"":""{0}"", ""italic"":""{1}"", ""bold"":""{2}"", ""font.name"":""{3}"", ""font.color"":""{4}"", ""font.size"":""{5}""".format(run.text, run.italic, run.bold, run.font.name, run.font.color.rgb, run.font.size))

            currRuns["runCount"] = currRunList
            currRuns["runDetails"] = currRunDetails

            paraIndexList.append(paraCount)
            paraTextList.append(para.text)
            paraRunList.append(currRuns)

        paraDict = {}
        paraDict["paraIndex"] = paraIndexList
        paraDict["paraText"] = paraTextList
        paraDict["paraRuns"] = paraRunList

        return paraDict

    # Returns Structured list of Paragraphs Details in the Word Document, that can be stored in CVS in Tabular format
    def getParagraphListSturctured(self):
        print("--------------------- Creating list of Paragraphs in Document in Structured Format ----------------------------")
        paraCount = 0
        rowNum = 0
        paraName = ""
        paraText = ""
        allParasDict = {}

        print("Number of paragraphs: ", len(self.document.paragraphs))
        for para in self.document.paragraphs:
            paraCount += 1
            paraName = "Paragraph " + str(paraCount)
            paraText = para.text
            runCount = 0        # initializing runCount for every paragraph
            for run in para.runs:
                rowNum += 1
                runCount += 1
                currRunDict = {}
                print("Para:{0}, Run:{1}".format(paraCount,  runCount))
                print("text:{0},\nitalic:{1},\nbold:{2},\nfont.name:{3},\nfont.color:{4},\nfont.size:{5}".format(run.text, run.italic, run.bold, run.font.name, run.font.color.rgb, run.font.size))
                currRunDict["paraName"] = paraName
                currRunDict["paraText"] = paraText
                currRunDict["runName"] = "Run " + str(runCount)
                currRunDict["text"] = run.text
                currRunDict["italic"] = run.italic
                currRunDict["bold"] = run.bold
                currRunDict["font.name"] = run.font.name
                currRunDict["font.color"] = run.font.color.rgb
                currRunDict["font.highlight_color"] = run.font.highlight_color
                currRunDict["font.size"] = run.font.size
                allParasDict[rowNum] = currRunDict

        # paraDict = {}
        # paraDict["paragraphs"] = allParasDict
        return allParasDict


    # Returns Structured list of Paragraphs Text in the Word Document, that can be stored in the Repository
    def getParagraphTextForRepository(self):
        print("--------------------- Creating list of Paragraphs Text present in Document in Structured Format for Repository ----------------------------")
        paraCount = 0
        allPagesList = []
        allParasList = []

        print("Number of paragraphs: ", len(self.document.paragraphs))
        for para in self.document.paragraphs:
            paraCount += 1
            paraText = para.text
            currParaList = []
            currParaList.append(paraCount)
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append("")
            currParaList.append(paraText)
            allParasList.append(currParaList)
        allPagesList.append(allParasList)
        return allPagesList
