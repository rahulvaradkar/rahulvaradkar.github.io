USE BAE_4_7_TARGET
GO

IF OBJECT_ID(N'dbo.BRectDefinition', N'U') IS NOT NULL  
   DROP TABLE [dbo].[BRectDefinition];  
GO


SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BRectDefinition] (
	[Root NH] [nvarchar](2048) NULL
	,[Business Unit] [nvarchar](2048) NULL
	,[App] [nvarchar](2048) NULL
	,[BrectName] [nvarchar](2048) NULL
	,[Database] [nvarchar](2048) NULL
	,[Type] [nvarchar](2048) NULL
	,[Name] [nvarchar](2048) NULL
	,[WhiteBoard] [nvarchar](2048) NULL
	,[Collaboration] [nvarchar](2048) NULL
	,[Neighborhood] [nvarchar](2048) NULL
	) ON [PRIMARY]
GO

--truncate table  [BRectDefinition]
--truncate table keystore
--truncate  table S2C_SuperMerge_Rules

INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'BRectDefinition'
	,'BRect'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_BRectDefinition'
	,''
	,''
	,''
	)

	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'KeyStore'
	,'KeyStore'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_KeyStore'
	,''
	,''
	,''
	)


	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'NOTIFICATION_CONFIG'
	,'Configuration'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_NOTIFICATION_CONFIG'
	,''
	,''
	,''
	)

	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'INTEGRATION_RULES'
	,'SuperMerge'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_INTEGRATION_RULES'
	,''
	,''
	,''
	)


	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'Multi_C2C_SuperMerge_Rules'
	,'SuperMerge'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_Multi_C2C_SuperMerge_Rules'
	,''
	,''
	,''
	)


	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'S2C_SuperMerge_Rules'
	,'SuperMerge'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_S2C_SuperMerge_Rules'
	,''
	,''
	,''
	)

	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'C2S_SuperMerge_Rules'
	,'SuperMerge'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_C2S_SuperMerge_Rules'
	,''
	,''
	,''
	)


	INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_TGT'
	,DB_NAME()
	,'CUBOID'
	,'C2C_SuperMerge_Rules'
	,'SuperMerge'
	,'SYSTEM'
	,'ROOT|||'
	)


INSERT INTO [BRectDefinition] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[BrectName]
	,[Database]
	,[Type]
	,[Name]
	,[WhiteBoard]
	,[Collaboration]
	,[Neighborhood]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_SRC'
	,DB_NAME()
	,'SQL'
	,'SQL_C2C_SuperMerge_Rules'
	,''
	,''
	,''
	)


	--------keystore---------------
	
IF OBJECT_ID(N'dbo.keystore', N'U') IS NOT NULL  
   DROP TABLE [dbo].[keystore];  
GO

	SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[keystore] (
	[Root NH] [nvarchar](2048) NULL
	,[Business Unit] [nvarchar](2048) NULL
	,[App] [nvarchar](2048) NULL
	,[KeyName] [nvarchar](2048) NULL
	,[Type] [nvarchar](2048) NULL
	,[DataSource] [nvarchar](2048) NULL
	,[Name] [nvarchar](2048) NULL
	,[Key] [nvarchar](2048) NULL
	) ON [PRIMARY]
GO

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'BRectDifinition_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,BrectName'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'BRectDifinition_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,BrectName'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'BRectDifinition_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Collaboration,Database,Name,Neighborhood,Type,WhiteBoard'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'BRectDifinition_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Collaboration,Database,Name,Neighborhood,Type,WhiteBoard'
	)



	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'KeyStore_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,KeyName'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'KeyStore_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,KeyName'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'KeyStore_Migration_SRC'
	,'1000003_KEYSTORE'
	,'DataSource,Key,Name,Type'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'KeyStore_Migration_TGT'
	,'1000003_KEYSTORE'
	,'DataSource,Key,Name,Type'
	)


	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'Notification_Config_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,ID'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'Notification_Config_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,ID'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'Notification_Config_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Attachment,BCC EmailID List,CC EmailID List,Description,Notification Body,Notification Footer,Notification Name,Notification Profile Name,Notification Subject,Notification Type,Status,To EmailID List'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'Notification_Config_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Attachment,BCC EmailID List,CC EmailID List,Description,Notification Body,Notification Footer,Notification Name,Notification Profile Name,Notification Subject,Notification Type,Status,To EmailID List'
	)


	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'INTEGRATION_RULES_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'INTEGRATION_RULES_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'INTEGRATION_RULES_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Created By,Date Created,Date Last Updated,Failure Notification,Post Execution Call,Pre Execution Call,Rule Description,Status,Success Notification,Type,Updated By'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'INTEGRATION_RULES_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Created By,Date Created,Date Last Updated,Failure Notification,Post Execution Call,Pre Execution Call,Rule Description,Status,Success Notification,Type,Updated By'
	)

	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'S2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'S2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'S2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationFlag,AggregationKey,AggregationOperator,BrectTableID,DeleteFlag,FormulaBrect,FormulaFlag,FormulaPrimaryKey,GroupByKey,InsertFlag,KeystoreTableID,MeasuresFlag,OrderByKey,SourceBrect,SourcePrimaryKey,SourceUpdateKey,TargetBrect,TargetMeasureKey,TargetPrimaryKey,TargetUpdateKey,TransposeFlag,TransposeKey,UpdateFlag'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'S2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationFlag,AggregationKey,AggregationOperator,BrectTableID,DeleteFlag,FormulaBrect,FormulaFlag,FormulaPrimaryKey,GroupByKey,InsertFlag,KeystoreTableID,MeasuresFlag,OrderByKey,SourceBrect,SourcePrimaryKey,SourceUpdateKey,TargetBrect,TargetMeasureKey,TargetPrimaryKey,TargetUpdateKey,TransposeFlag,TransposeKey,UpdateFlag'
	)


	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'BrectTableID,DeleteFlag,InsertFlag,KeystoreTableID,SourceBrect1,SourceBrect2,SourceMatchKey1,SourceMatchKey2,SourcePrimaryKey1,SourcePrimaryKey2,SourceUpdateKey1,SourceUpdateKey2,TargetBrect,TargetPrimaryKey,TargetUpdateKey,UpdateFlag'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'BrectTableID,DeleteFlag,InsertFlag,KeystoreTableID,SourceBrect1,SourceBrect2,SourceMatchKey1,SourceMatchKey2,SourcePrimaryKey1,SourcePrimaryKey2,SourceUpdateKey1,SourceUpdateKey2,TargetBrect,TargetPrimaryKey,TargetUpdateKey,UpdateFlag'
	)

	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'C2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'C2C_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationEachSliceFlag,AggregationFunction,AggregationFunctionBySlice,AggregationSliceFlag,BlankTargetFlag,BrectTableID,DeleteFlag,GroupByKey,IncludeTagName,InsertFlag,KeystoreTableIDGroupBy,KeystoreTableIDOrderBy,KeystoreTableIDSource,KeystoreTableIDTarget,KeystoreTableIDUpdateKey,MapSource,MapTableID,MapTarget,OrderByKey,SourceBrect,SourcePrimaryKey,SourceUpdateKey,StopOnNonFloat,TargetBrect,TargetPrimaryKey,TargetSampleBrect,TargetUpdateKey,TransposeColumnSource,TransposeTimeColumnTarget,UpdateFlag'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationEachSliceFlag,AggregationFunction,AggregationFunctionBySlice,AggregationSliceFlag,BlankTargetFlag,BrectTableID,DeleteFlag,GroupByKey,IncludeTagName,InsertFlag,KeystoreTableIDGroupBy,KeystoreTableIDOrderBy,KeystoreTableIDSource,KeystoreTableIDTarget,KeystoreTableIDUpdateKey,MapSource,MapTableID,MapTarget,OrderByKey,SourceBrect,SourcePrimaryKey,SourceUpdateKey,StopOnNonFloat,TargetBrect,TargetPrimaryKey,TargetSampleBrect,TargetUpdateKey,TransposeColumnSource,TransposeTimeColumnTarget,UpdateFlag'
	)




	INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_SRC_PK'
	,'PRIMARY_KEY'
	,'C2S_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_TGT_PK'
	,'PRIMARY_KEY'
	,'C2S_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'Root NH,Business Unit,App,Rule Name'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_SRC_UPD'
	,'UPDATE_KEY'
	,'C2S_SuperMerge_Rules_Migration_SRC'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationColumnType,AggregationFlag,AggregationKey,AggregationOperator,BrectTableID,BWIDFlag,ColumnMapFlag,ColumnMapSource,ColumnMapTarget,FilterString,GroupByKey,KeystoreTableID,SourceBrect,SourcePrimaryKey,TransposeKey,TXID,TXIDFlag'
	)

INSERT INTO keystore (
	[Root NH]
	,[Business Unit]
	,[App]
	,[KeyName]
	,[Type]
	,[DataSource]
	,[Name]
	,[Key]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_TGT_UPD'
	,'UPDATE_KEY'
	,'C2S_SuperMerge_Rules_Migration_TGT'
	,'1000003_KEYSTORE'
	,'AccessTableID,AggregationColumnType,AggregationFlag,AggregationKey,AggregationOperator,BrectTableID,BWIDFlag,ColumnMapFlag,ColumnMapSource,ColumnMapTarget,FilterString,GroupByKey,KeystoreTableID,SourceBrect,SourcePrimaryKey,TransposeKey,TXID,TXIDFlag'
	)


	-------------------------S2C---------------------------

	
IF OBJECT_ID(N'dbo.S2C_SuperMerge_Rules', N'U') IS NOT NULL  
   DROP TABLE [dbo].[S2C_SuperMerge_Rules];  
GO



	SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[S2C_SuperMerge_Rules] (
	[Root NH] [nvarchar](2048) NULL
	,[Business Unit] [nvarchar](2048) NULL
	,[App] [nvarchar](2048) NULL
	,[RuleName] [nvarchar](2048) NULL
	,[AccessTableID] [nvarchar](2048) NULL
	,[BrectTableID] [nvarchar](2048) NULL
	,[SourceBrect] [nvarchar](2048) NULL
	,[TargetBrect] [nvarchar](2048) NULL
	,[KeystoreTableID] [nvarchar](2048) NULL
	,[SourcePrimaryKey] [nvarchar](2048) NULL
	,[TargetPrimaryKey] [nvarchar](2048) NULL
	,[SourceUpdateKey] [nvarchar](2048) NULL
	,[TargetUpdateKey] [nvarchar](2048) NULL
	,[InsertFlag] [nvarchar](2048) NULL
	,[OrderByKey] [nvarchar](2048) NULL
	,[AggregationFlag] [nvarchar](2048) NULL
	,[AggregationOperator] [nvarchar](2048) NULL
	,[AggregationKey] [nvarchar](2048) NULL
	,[GroupByKey] [nvarchar](2048) NULL
	,[UpdateFlag] [nvarchar](2048) NULL
	,[DeleteFlag] [nvarchar](2048) NULL
	,[TransposeFlag] [nvarchar](2048) NULL
	,[TransposeKey] [nvarchar](2048) NULL
	,[MeasuresFlag] [nvarchar](2048) NULL
	,[TargetMeasureKey] [nvarchar](2048) NULL
	,[FormulaFlag] [nvarchar](2048) NULL
	,[FormulaBrect] [nvarchar](2048) NULL
	,[FormulaPrimaryKey] [nvarchar](2048) NULL
	) ON [PRIMARY]
GO

INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'BRectDifinition_Migration'
	,''
	,'1000002'
	,'BRectDifinition_Migration_SRC'
	,'BRectDifinition_Migration_TGT'
	,'1000003'
	,'BRectDifinition_Migration_SRC_PK'
	,'BRectDifinition_Migration_TGT_PK'
	,'BRectDifinition_Migration_SRC_UPD'
	,'BRectDifinition_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'BRectDifinition_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'KeyStore_Migration'
	,''
	,'1000002'
	,'KeyStore_Migration_SRC'
	,'KeyStore_Migration_TGT'
	,'1000003'
	,'KeyStore_Migration_SRC_PK'
	,'KeyStore_Migration_TGT_PK'
	,'KeyStore_Migration_SRC_UPD'
	,'KeyStore_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'KeyStore_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	
	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'Notification_Config_Migration'
	,''
	,'1000002'
	,'Notification_Config_Migration_SRC'
	,'Notification_Config_Migration_TGT'
	,'1000003'
	,'Notification_Config_Migration_SRC_PK'
	,'Notification_Config_Migration_TGT_PK'
	,'Notification_Config_Migration_SRC_UPD'
	,'Notification_Config_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'Notification_Config_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'INTEGRATION_RULES_Migration'
	,''
	,'1000002'
	,'INTEGRATION_RULES_Migration_SRC'
	,'INTEGRATION_RULES_Migration_TGT'
	,'1000003'
	,'INTEGRATION_RULES_Migration_SRC_PK'
	,'INTEGRATION_RULES_Migration_TGT_PK'
	,'INTEGRATION_RULES_Migration_SRC_UPD'
	,'INTEGRATION_RULES_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'INTEGRATION_RULES_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)




	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration'
	,''
	,'1000002'
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC'
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003'
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC_PK'
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT_PK'
	,'Multi_C2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'Multi_C2C_SuperMerge_Rules_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'Multi_C2C_SuperMerge_Rules_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	
	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration'
	,''
	,'1000002'
	,'S2C_SuperMerge_Rules_Migration_SRC'
	,'S2C_SuperMerge_Rules_Migration_TGT'
	,'1000003'
	,'S2C_SuperMerge_Rules_Migration_SRC_PK'
	,'S2C_SuperMerge_Rules_Migration_TGT_PK'
	,'S2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'S2C_SuperMerge_Rules_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'S2C_SuperMerge_Rules_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration'
	,''
	,'1000002'
	,'C2S_SuperMerge_Rules_Migration_SRC'
	,'C2S_SuperMerge_Rules_Migration_TGT'
	,'1000003'
	,'C2S_SuperMerge_Rules_Migration_SRC_PK'
	,'C2S_SuperMerge_Rules_Migration_TGT_PK'
	,'C2S_SuperMerge_Rules_Migration_SRC_UPD'
	,'C2S_SuperMerge_Rules_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'C2S_SuperMerge_Rules_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)



	INSERT INTO [dbo].[S2C_SuperMerge_Rules] (
	[Root NH]
	,[Business Unit]
	,[App]
	,[RuleName]
	,[AccessTableID]
	,[BrectTableID]
	,[SourceBrect]
	,[TargetBrect]
	,[KeystoreTableID]
	,[SourcePrimaryKey]
	,[TargetPrimaryKey]
	,[SourceUpdateKey]
	,[TargetUpdateKey]
	,[InsertFlag]
	,[OrderByKey]
	,[AggregationFlag]
	,[AggregationOperator]
	,[AggregationKey]
	,[GroupByKey]
	,[UpdateFlag]
	,[DeleteFlag]
	,[TransposeFlag]
	,[TransposeKey]
	,[MeasuresFlag]
	,[TargetMeasureKey]
	,[FormulaFlag]
	,[FormulaBrect]
	,[FormulaPrimaryKey]
	)
VALUES (
	''
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration'
	,''
	,'1000002'
	,'C2C_SuperMerge_Rules_Migration_SRC'
	,'C2C_SuperMerge_Rules_Migration_TGT'
	,'1000003'
	,'C2C_SuperMerge_Rules_Migration_SRC_PK'
	,'C2C_SuperMerge_Rules_Migration_TGT_PK'
	,'C2C_SuperMerge_Rules_Migration_SRC_UPD'
	,'C2C_SuperMerge_Rules_Migration_TGT_UPD'
	,1
	,''
	,0
	,''
	,''
	,'C2C_SuperMerge_Rules_Migration_AGGREGATION_TGT'
	,1
	,0
	,0
	,''
	,0
	,''
	,0
	,''
	,''
	)

	
	
----------------------------------------	
	


IF OBJECT_ID(N'dbo.BW_CUBOID_CREATION_LIST', N'U') IS NOT NULL  
   DROP TABLE [dbo].[BW_CUBOID_CREATION_LIST];  
GO


/****** Object:  Table [dbo].[BW_CUBOID_CREATION_LIST]    Script Date: 05/18/2022 14:26:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE BW_CUBOID_CREATION_LIST (
	ID INT IDENTITY(1, 1)
	,CUBOID_NAME NVARCHAR(256)
	,WB_NAME NVARCHAR(256)
	,Collab_Name NVARCHAR(256)
	)

--TRUNCATE TABLE BW_CUBOID_CREATION_LIST
	 INSERT INTO BW_CUBOID_CREATION_LIST
VALUES (
	'BRectDefinition'
	,'BRect'
	,'SYSTEM'
	)


		 INSERT INTO BW_CUBOID_CREATION_LIST
VALUES (
	'KEYSTORE'
	,'KeyStore'
	,'SYSTEM'
	)

	
		 INSERT INTO BW_CUBOID_CREATION_LIST
VALUES (
	'S2C_SuperMerge_Rules'
	,'SuperMerge'
	,'SYSTEM'
	)


DECLARE @FILE_CNT AS INT

SELECT @FILE_CNT = COUNT(*)
FROM BW_CUBOID_CREATION_LIST

SELECT @FILE_CNT

IF @FILE_CNT > 0
BEGIN
	DECLARE @CUBOID_NAME NVARCHAR(256)
	DECLARE @WBNAME NVARCHAR(256)
	DECLARE @Collab_name NVARCHAR(256)

	DECLARE FILEEXEC CURSOR
	FOR
	SELECT CUBOID_NAME
		,WB_NAME
		,collab_name
	FROM BW_CUBOID_CREATION_LIST

	
	DECLARE @CUB_ID INT
	SELECT @CUB_ID = ID FROM BW_TBL WHERE NAME = @CUBOID_NAME
	SELECT @CUB_ID

	OPEN FILEEXEC

	FETCH NEXT
	FROM FILEEXEC
	INTO @CUBOID_NAME
		,@WBNAME
		,@Collab_name

	SELECT @CUBOID_NAME

	SELECT @WBNAME

	SELECT @Collab_name


	WHILE @@FETCH_STATUS = 0
	BEGIN
		--[BW_DEFAULT_TEMPLATES_SQL]
		--DECLARE @CUBOID_NAME	AS NVARCHAR(256) =  'BW_DEFAULT_MANIFESTS_TEST'-- 'ITEM_MASTER_UPDATE'
		DECLARE @SQL_TBL_NAME AS NVARCHAR(256) = @CUBOID_NAME --'BW_DEFAULT_MANIFESTS_SQL'--'ITEM_MASTER_UPDATE'
		DECLARE @TBL_ID AS INT
		DECLARE @WHITEBOARD_ID AS INT
		DECLARE @WB_ID AS INT --= 1238
		DECLARE @MEMBER_ID AS INT
		DECLARE @TX_ID AS INT
		DECLARE @NEW_TBL_ID AS INT
		DECLARE @ALTER_TBL AS NVARCHAR(256)
		DECLARE @collab_id INT

		SELECT @collab_id = id
		FROM BW_COLLAB
		WHERE name = @Collab_name

		SELECT @WB_ID = ID
		FROM BW_WB
		WHERE NAME = @WBNAME
			AND BW_COLLAB_ID = @collab_id

		SELECT @WB_ID

		SELECT @MEMBER_ID = ID
		FROM BW_MEMBER
		WHERE NEIGHBORHOOD_ID = 1

		SELECT @MEMBER_ID

		EXEC [BW_GET_NEW_TX_ID_WITH_COMMENT] 2
			,'TBL_CREATION'
			,'TBL_CREATION'
			,@TX_ID OUTPUT

		SELECT @TX_ID

		DECLARE @SQL1 AS NVARCHAR(MAX)

		SET @SQL1 = '' + @CUBOID_NAME + ''

		SELECT @SQL1

		--EXEC BW_CR_BASIC_TBL 2
		--	,@MEMBER_ID
		--	,@WB_ID
		--	,@SQL1
		--	,'DEFAULT_CUBOID_CREATION'
		--	,@TBL_ID OUTPUT

		SELECT @NEW_TBL_ID = ID
		FROM BW_TBL
		WHERE NAME = @SQL1
			AND BW_WB_ID = @WB_ID

		PRINT 'NEWTBLID'
		PRINT @NEW_TBL_ID

		SET @ALTER_TBL = 'ALTER TABLE [' + @SQL1 + ']  ADD BW_ROW_ID INT,SEQUENCE_NUMBER INT IDENTITY(1,1)'

		SELECT @ALTER_TBL

		EXECUTE (@ALTER_TBL)

		-----------INSERT INTO BW_ROW------------------
		
DECLARE @TX_ID_NEW AS INT
EXEC [BW_GET_NEW_TX_ID_WITH_COMMENT] 2,'ROW_CREATION','ROW_CREATION',@TX_ID_NEW OUTPUT
SELECT @TX_ID_NEW
DECLARE @ROW_ID AS INT
DECLARE @TABLE_ID  AS INT = @NEW_TBL_ID

	DECLARE @USER_ID AS INTEGER
		SELECT  @USER_ID = BW_TXS.CREATED_BY
		FROM    BW_TXS
		WHERE 	BW_TXS.TX_ID =  @TX_ID_NEW

	DECLARE @SQL_INSERT AS NVARCHAR(MAX) 
	SET @SQL_INSERT= 'INSERT INTO BW_ROW
		( 
			NAME, 
			BW_TBL_ID, 
			TX_ID, 
			SEQUENCE_NUMBER,
			OWNER_ID,
			OWNER_TID
		)
		SELECT ''''' + ','+CAST(@NEW_TBL_ID AS VARCHAR(256)) +','+CAST(@TX_ID_NEW AS VARCHAR(256)) +',SEQUENCE_NUMBER,'+CAST(@USER_ID AS VARCHAR(256)) +','+CAST(@TX_ID_NEW AS VARCHAR(256))+' FROM '+ @SQL_TBL_NAME 
		
		PRINT @SQL_INSERT
		SELECT(@SQL_INSERT)
		EXECUTE(@SQL_INSERT)
		SELECT @ROW_ID = @@IDENTITY	
				
		DECLARE @SQL NVARCHAR(MAX) 
		SET @SQL= 'UPDATE '+ @SQL_TBL_NAME + ' SET BW_ROW_ID = R.ID FROM BW_ROW R,'+ @SQL_TBL_NAME + ' WHERE R.SEQUENCE_NUMBER = ' +@SQL_TBL_NAME+ '.SEQUENCE_NUMBER  AND BW_TBL_ID = '+ CAST(@NEW_TBL_ID AS VARCHAR(256))+'
		AND R.TX_ID ='+ CAST(@TX_ID_NEW AS VARCHAR(256))
		

		SELECT @SQL

		PRINT 'UPDATE BW_ROW_ID' + @SQL
		EXECUTE(@SQL);

		select @NEW_TBL_ID
			   
TRUNCATE TABLE BW_COLUMN_SQL
INSERT INTO  BW_COLUMN_SQL (NAME,BW_TBL_ID,BW_COLUMN_ID)
SELECT NAME,BW_TBL_ID,ID FROM BW_COLUMN WHERE BW_TBL_ID = @NEW_TBL_ID





--DELETE FROM BW_COLUMN_SQL WHERE BW_COLUMN_ID IS NULL

SELECT * FROM BW_COLUMN_SQL


--DECLARE @TX_ID_NEW AS INT
--DECLARE @SQL_TBL_NAME AS NVARCHAR(256) = 'ITEM_MASTER_SQL_INSERT'
EXEC [BW_GET_NEW_TX_ID_WITH_COMMENT] 2,'CELL_CREATION','CELL_CREATION',@TX_ID_NEW OUTPUT
SELECT @TX_ID_NEW
		-- INSERT INTO THE CELL TABLE	
		DECLARE @SQL_CR_CELL AS NVARCHAR(MAX)
	SET @SQL_CR_CELL= 'INSERT INTO BW_CELL
		( 
			BW_ROW_ID,
			BW_COLUMN_ID,
			CELL_TYPE,
			STRING_VALUE,
			TX_ID, 
			ACTIVE
		)
		SELECT T2.BW_ROW_ID,T1.BW_COLUMN_ID,'+ '''STRING''' +','''','+CAST(@TX_ID_NEW AS VARCHAR(256))+',1  FROM BW_COLUMN_SQL T1,'+ @SQL_TBL_NAME +' T2'

	 SELECT @SQL_CR_CELL
	EXECUTE(@SQL_CR_CELL)

		-- INSERT INTO THE CELL STATUS TABLE
		INSERT INTO	BW_CELL_STATUS 
		(
			BW_CELL_ID ,  
			ACTIVE, 
			TX_ID 
		)
		SELECT 	BW_CELL.ID, 
				BW_CELL.ACTIVE, 
				@TX_ID_NEW
		FROM	BW_CELL
		WHERE 	BW_CELL.TX_ID = @TX_ID_NEW


		--CREATE NEW STRING VALUES
		INSERT INTO BW_STRING_VALUE
		SELECT 	BW_CELL.ID, 
				BW_CELL.STRING_VALUE, 
				BW_CELL.TX_ID 
		FROM 	BW_CELL 
		WHERE 	BW_CELL.TX_ID = @TX_ID_NEW

		-- UPDATE BACK THE STRING VALUE IDS
		UPDATE 	BW_CELL 
		SET 	BW_STRINGVALUE_ID = BW_STRING_VALUE.ID 
		FROM 	BW_STRING_VALUE 
		WHERE 	BW_STRING_VALUE.BW_CELL_ID = BW_CELL.ID  
		AND 	BW_STRING_VALUE.TX_ID = @TX_ID_NEW

		SET ANSI_NULLS ON



--------------------UPDATE RC STRING VALUE-----------------------------


	--DECLARE @SQL_INSERT AS NVARCHAR(MAX)
	--DECLARE @SQL_TBL_NAME AS NVARCHAR(256) = 'ITEM_MASTER_SQL_INSERT'
	DECLARE @CUBOID_ID INT  = @CUB_ID
	TRUNCATE TABLE BW_ITEM_TEMP
	SET @SQL_INSERT = 'INSERT INTO BW_ITEM_TEMP(BW_ROW_ID,BW_COLUMN_ID,NAME,STRING_VALUE)
	SELECT 
	I.BW_ROW_ID,C.ID,C.NAME,'''' FROM BW_COLUMN C,' + @SQL_TBL_NAME + ' I
	WHERE  C.BW_TBL_ID = '+CAST(@NEW_TBL_ID AS VARCHAR(256))+' AND C.IS_ACTIVE = 1 '

	PRINT @SQL_INSERT
	EXECUTE(@SQL_INSERT)
	--SELECT * FROM BW_ITEM_TEMP



	DECLARE @NAME NVARCHAR(256)
	DECLARE @ID NVARCHAR(20)
	DECLARE @SQL_UPD NVARCHAR(256)
	DECLARE CURSOR_UPD  CURSOR  FOR

		SELECT ID,NAME FROM BW_COLUMN WHERE  BW_TBL_ID = @NEW_TBL_ID AND IS_ACTIVE = 1

		OPEN CURSOR_UPD

		FETCH NEXT FROM CURSOR_UPD INTO @ID,@NAME

		WHILE @@FETCH_STATUS = 0

		BEGIN

		SET @SQL_UPD= 
				'UPDATE T
				SET T.STRING_VALUE = I.[' + @NAME + ']
				FROM '+@SQL_TBL_NAME+' I,BW_ITEM_TEMP T
				WHERE I.BW_ROW_ID = T.BW_ROW_ID
				AND T.[NAME] = '''+@NAME +''''

				--SELECT @SQL
				PRINT @SQL_UPD

				EXECUTE(@SQL_UPD)
	

		FETCH NEXT FROM CURSOR_UPD INTO @ID,@NAME

		END


		CLOSE CURSOR_UPD
		DEALLOCATE CURSOR_UPD


			DECLARE @TX_ID_UPD AS INT
			EXEC [BW_GET_NEW_TX_ID_WITH_COMMENT] 2,'NEW ROW UPDATE CELL','NEW ROW UPDATE CELL DONE',@TX_ID_UPD OUTPUT
				INSERT INTO BW_RC_STRING_VALUE
				SELECT BW_ROW_ID,BW_COLUMN_ID,STRING_VALUE,
				'',@TX_ID_UPD,3
				FROM BW_ITEM_TEMP
	


	EXEC BW_UPD_CELL_FROM_RCSV  @TX_ID_UPD,@TX_ID_UPD,@NEW_TBL_ID,2
		FETCH NEXT
		FROM FILEEXEC
		INTO @CUBOID_NAME
			,@WBNAME
			,@Collab_name
	END

	CLOSE FILEEXEC

	DEALLOCATE FILEEXEC
END


--declare @ALTER_TBL nvarchar(max)
SET @ALTER_TBL = 'ALTER TABLE ' + @SQL_TBL_NAME + '  DROP COLUMN  BW_ROW_ID,SEQUENCE_NUMBER '

		SELECT @ALTER_TBL

		EXECUTE (@ALTER_TBL)

--ALTER TABLE SystemConfiguration
--DROP COLUMN   sequence_number

--ALTER TABLE SystemConfiguration
--DROP COLUMN   bw_Row_id