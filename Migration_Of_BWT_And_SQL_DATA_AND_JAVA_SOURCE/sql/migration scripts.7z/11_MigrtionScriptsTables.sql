USE BAE_4_7_TARGET
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES]') AND parent_object_id = OBJECT_ID(N'[dbo].[BW_PACKAGE_DEPLOYMENT_LOG]'))
ALTER TABLE [dbo].[BW_PACKAGE_DEPLOYMENT_LOG] DROP CONSTRAINT [FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES]
GO

/****** Object:  Table [dbo].[SQL_NOTIFICATION_CONFIG]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_NOTIFICATION_CONFIG]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_NOTIFICATION_CONFIG]
GO

/****** Object:  Table [dbo].[SQL_INTEGRATION_RULES]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_INTEGRATION_RULES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_INTEGRATION_RULES]
GO

/****** Object:  Table [dbo].[SQL_Multi_C2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_Multi_C2C_SuperMerge_Rules]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_Multi_C2C_SuperMerge_Rules]
GO

/****** Object:  Table [dbo].[SQL_C2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_C2C_SuperMerge_Rules]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_C2C_SuperMerge_Rules]
GO

/****** Object:  Table [dbo].[SQL_C2S_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_C2S_SuperMerge_Rules]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_C2S_SuperMerge_Rules]
GO

/****** Object:  Table [dbo].[SQL_S2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_S2C_SuperMerge_Rules]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_S2C_SuperMerge_Rules]
GO

/****** Object:  Table [dbo].[SQL_BRectDefinition]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_BRectDefinition]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_BRectDefinition]
GO

/****** Object:  Table [dbo].[SQL_KeyStore]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_KeyStore]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_KeyStore]
GO

/****** Object:  Table [dbo].[BW_DEPLOYED_PACKAGES]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_DEPLOYED_PACKAGES]') AND type in (N'U'))
DROP TABLE [dbo].[BW_DEPLOYED_PACKAGES]
GO

/****** Object:  Table [dbo].[BW_MIGRATION_OBJECT_MAP]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_MIGRATION_OBJECT_MAP]') AND type in (N'U'))
DROP TABLE [dbo].[BW_MIGRATION_OBJECT_MAP]
GO

/****** Object:  Table [dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP]') AND type in (N'U'))
DROP TABLE [dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP]
GO

/****** Object:  Table [dbo].[BW_PACKAGE_DEPLOYMENT_LOG]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_PACKAGE_DEPLOYMENT_LOG]') AND type in (N'U'))
DROP TABLE [dbo].[BW_PACKAGE_DEPLOYMENT_LOG]
GO

/****** Object:  Table [dbo].[DOCU_CHAIN_DEFAULT_DATALOAD]    Script Date: 31-05-2022 21:19:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DOCU_CHAIN_DEFAULT_DATALOAD]') AND type in (N'U'))
DROP TABLE [dbo].[DOCU_CHAIN_DEFAULT_DATALOAD]
GO
/****** Object:  Table [dbo].[DOCU_CHAIN_DEFAULT_DATALOAD]    Script Date: 6/9/2022 12:16:27 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DOCU_CHAIN_DEFAULT_DATALOAD](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SQL_FILE_NAME] [nvarchar](256) NULL,
	[CUBOID_ID] [nvarchar](256) NULL,
	[CUBOID_NAME] [nvarchar](256) NULL
) ON [PRIMARY]
GO


/****** Object:  Table [dbo].[BW_PACKAGE_DEPLOYMENT_LOG]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_PACKAGE_DEPLOYMENT_LOG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BW_PACKAGE_DEPLOYMENT_LOG](
	[ID] [int] IDENTITY(1000,1) NOT NULL,
	[PACKAGE_ID] [int] NOT NULL,
	[PACKAGE_NAME] [varchar](1024) NOT NULL,
	[COMMAND_RUN_DATE] [datetime] NOT NULL,
	[COMMAND] [varchar](1024) NOT NULL,
	[PARAMS] [varchar](1024) NOT NULL,
	[RESULT] [varchar](100) NOT NULL,
	[LOG] [varchar](max) NOT NULL,
 CONSTRAINT [PK_BW_PACKAGE_DEPLOYMENT_LOG] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BW_CUBOID_ROWID_COLUMN_ID_MAP](
	[ID] [int] IDENTITY(1000,1) NOT NULL,
	[OBJECT_NAME] [varchar](512) NOT NULL,
	[CUBOID_NAME] [varchar](512) NOT NULL,
	[SOURCE_SERVER] [varchar](512) NOT NULL,
	[TARGET_SERVER] [varchar](512) NOT NULL,
	[SOURCE_CUBOID_ID] [int] NOT NULL,
	[TARGET_CUBOID_ID] [int] NOT NULL,
	[SOURCE_OBJECT_ID] [int] NOT NULL,
	[TARGET_OBJECT_ID] [int] NOT NULL,
	[OBJECT_TYPE] [varchar](512) NOT NULL,
	[SEQUENCE_NUMBER] [int] NOT NULL,
 CONSTRAINT [PK_BW_CUBOID_ROWID_COLUMN_ID_MAP] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[BW_MIGRATION_OBJECT_MAP]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_MIGRATION_OBJECT_MAP]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BW_MIGRATION_OBJECT_MAP](
	[ID] [int] IDENTITY(1000,1) NOT NULL,
	[OBJECT_NAME] [varchar](512) NOT NULL,
	[SOURCE_SERVER] [varchar](512) NOT NULL,
	[TARGET_SERVER] [varchar](512) NOT NULL,
	[SOURCE_OBJECT_ID] [int] NOT NULL,
	[TARGET_OBJECT_ID] [int] NOT NULL,
	[OBJECT_TYPE] [varchar](512) NOT NULL,
	[CREATION_TX_ID] [int] NOT NULL,
	[PACKAGE_NAME] [varchar](512) NOT NULL,
 CONSTRAINT [PK_BW_MIGRATION_OBJECT_MAP] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[BW_DEPLOYED_PACKAGES]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BW_DEPLOYED_PACKAGES]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BW_DEPLOYED_PACKAGES](
	[ID] [int] IDENTITY(1000,1) NOT NULL,
	[PACKAGE_NAME] [varchar](512) NOT NULL,
	[SOURCE_SERVER] [varchar](512) NOT NULL,
	[PACKAGE_CREATION_DATE] [datetime] NOT NULL,
	[PACKAGE_DEPLOYED_DATE] [datetime] NOT NULL,
	[PACKAGE_INFO] [varchar](1024) NOT NULL,
 CONSTRAINT [PK_BW_DEPLOYED_PACKAGES] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_KeyStore]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_KeyStore]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_KeyStore](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[KeyName] [varchar](2048) NULL,
	[Type] [varchar](2048) NULL,
	[DataSource] [varchar](2048) NULL,
	[Name] [varchar](2048) NULL,
	[Key] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_BRectDefinition]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_BRectDefinition]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_BRectDefinition](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[BrectName] [varchar](2048) NULL,
	[Database] [varchar](2048) NULL,
	[Type] [varchar](2048) NULL,
	[Name] [varchar](2048) NULL,
	[WhiteBoard] [varchar](2048) NULL,
	[Collaboration] [varchar](2048) NULL,
	[Neighborhood] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_S2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_S2C_SuperMerge_Rules]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_S2C_SuperMerge_Rules](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[RuleName] [varchar](2048) NULL,
	[AccessTableID] [varchar](2048) NULL,
	[BrectTableID] [varchar](2048) NULL,
	[SourceBrect] [varchar](2048) NULL,
	[TargetBrect] [varchar](2048) NULL,
	[KeystoreTableID] [varchar](2048) NULL,
	[SourcePrimaryKey] [varchar](2048) NULL,
	[TargetPrimaryKey] [varchar](2048) NULL,
	[SourceUpdateKey] [varchar](2048) NULL,
	[TargetUpdateKey] [varchar](2048) NULL,
	[InsertFlag] [varchar](2048) NULL,
	[OrderByKey] [varchar](2048) NULL,
	[AggregationFlag] [varchar](2048) NULL,
	[AggregationOperator] [varchar](2048) NULL,
	[AggregationKey] [varchar](2048) NULL,
	[GroupByKey] [varchar](2048) NULL,
	[UpdateFlag] [varchar](2048) NULL,
	[DeleteFlag] [varchar](2048) NULL,
	[TransposeFlag] [varchar](2048) NULL,
	[TransposeKey] [varchar](2048) NULL,
	[MeasuresFlag] [varchar](2048) NULL,
	[TargetMeasureKey] [varchar](2048) NULL,
	[FormulaFlag] [varchar](2048) NULL,
	[FormulaBrect] [varchar](2048) NULL,
	[FormulaPrimaryKey] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_C2S_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_C2S_SuperMerge_Rules]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_C2S_SuperMerge_Rules](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[RuleName] [varchar](2048) NULL,
	[AccessTableID] [varchar](2048) NULL,
	[BrectTableID] [varchar](2048) NULL,
	[SourceBrect] [varchar](2048) NULL,
	[KeystoreTableID] [varchar](2048) NULL,
	[SourcePrimaryKey] [varchar](2048) NULL,
	[TransposeKey] [varchar](2048) NULL,
	[GroupByKey] [varchar](2048) NULL,
	[AggregationFlag] [varchar](2048) NULL,
	[AggregationOperator] [varchar](2048) NULL,
	[AggregationColumnType] [varchar](2048) NULL,
	[AggregationKey] [varchar](2048) NULL,
	[TXIDFlag] [varchar](2048) NULL,
	[TXID] [varchar](2048) NULL,
	[BWIDFlag] [varchar](2048) NULL,
	[ColumnMapFlag] [varchar](2048) NULL,
	[ColumnMapSource] [varchar](2048) NULL,
	[ColumnMapTarget] [varchar](2048) NULL,
	[FilterString] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_C2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_C2C_SuperMerge_Rules]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_C2C_SuperMerge_Rules](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[RuleName] [varchar](2048) NULL,
	[AccessTableID] [varchar](2048) NULL,
	[BrectTableID] [varchar](2048) NULL,
	[SourceBrect] [varchar](2048) NULL,
	[KeystoreTableIDSource] [varchar](2048) NULL,
	[SourcePrimaryKey] [varchar](2048) NULL,
	[TargetBrect] [varchar](2048) NULL,
	[TargetSampleBrect] [varchar](2048) NULL,
	[KeystoreTableIDTarget] [varchar](2048) NULL,
	[TargetPrimaryKey] [varchar](2048) NULL,
	[KeystoreTableIDUpdateKey] [varchar](2048) NULL,
	[SourceUpdateKey] [varchar](2048) NULL,
	[TargetUpdateKey] [varchar](2048) NULL,
	[IncludeTagName] [varchar](2048) NULL,
	[AggregationEachSliceFlag] [varchar](2048) NULL,
	[AggregationFunctionBySlice] [varchar](2048) NULL,
	[AggregationSliceFlag] [varchar](2048) NULL,
	[AggregationFunction] [varchar](2048) NULL,
	[KeystoreTableIDGroupBy] [varchar](2048) NULL,
	[GroupByKey] [varchar](2048) NULL,
	[InsertFlag] [varchar](2048) NULL,
	[DeleteFlag] [varchar](2048) NULL,
	[UpdateFlag] [varchar](2048) NULL,
	[BlankTargetFlag] [varchar](2048) NULL,
	[StopOnNonFloat] [varchar](2048) NULL,
	[KeystoreTableIDOrderBy] [varchar](2048) NULL,
	[OrderByKey] [varchar](2048) NULL,
	[TransposeTimeColumnTarget] [varchar](2048) NULL,
	[TransposeColumnSource] [varchar](2048) NULL,
	[MapTableID] [varchar](2048) NULL,
	[MapSource] [varchar](2048) NULL,
	[MapTarget] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_Multi_C2C_SuperMerge_Rules]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_Multi_C2C_SuperMerge_Rules]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_Multi_C2C_SuperMerge_Rules](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[RuleName] [varchar](2048) NULL,
	[BrectTableID] [varchar](2048) NULL,
	[SourceBrect1] [varchar](2048) NULL,
	[SourceBrect2] [varchar](2048) NULL,
	[TargetBrect] [varchar](2048) NULL,
	[KeystoreTableID] [varchar](2048) NULL,
	[SourcePrimaryKey1] [varchar](2048) NULL,
	[SourcePrimaryKey2] [varchar](2048) NULL,
	[TargetPrimaryKey] [varchar](2048) NULL,
	[SourceMatchKey1] [varchar](2048) NULL,
	[SourceMatchKey2] [varchar](2048) NULL,
	[SourceUpdateKey1] [varchar](2048) NULL,
	[SourceUpdateKey2] [varchar](2048) NULL,
	[TargetUpdateKey] [varchar](2048) NULL,
	[InsertFlag] [varchar](2048) NULL,
	[UpdateFlag] [varchar](2048) NULL,
	[DeleteFlag] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_INTEGRATION_RULES]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_INTEGRATION_RULES]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_INTEGRATION_RULES](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[Rule Name] [varchar](2048) NULL,
	[Rule Description] [varchar](2048) NULL,
	[Type] [varchar](2048) NULL,
	[Status] [varchar](2048) NULL,
	[Pre Execution Call] [varchar](2048) NULL,
	[Post Execution Call] [varchar](2048) NULL,
	[Success Notification] [varchar](2048) NULL,
	[Failure Notification] [varchar](2048) NULL,
	[Created By] [varchar](2048) NULL,
	[Date Created] [varchar](2048) NULL,
	[Updated By] [varchar](2048) NULL,
	[Date Last Updated] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQL_NOTIFICATION_CONFIG]    Script Date: 31-05-2022 21:19:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_NOTIFICATION_CONFIG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQL_NOTIFICATION_CONFIG](
	[Root NH] [varchar](2048) NULL,
	[Business Unit] [varchar](2048) NULL,
	[App] [varchar](2048) NULL,
	[ID] [varchar](2048) NULL,
	[Notification Type] [varchar](2048) NULL,
	[Description] [varchar](2048) NULL,
	[Notification Name] [varchar](2048) NULL,
	[Notification Subject] [varchar](2048) NULL,
	[Notification Body] [varchar](2048) NULL,
	[Notification Footer] [varchar](2048) NULL,
	[Notification Profile Name] [varchar](2048) NULL,
	[To EmailID List] [varchar](2048) NULL,
	[CC EmailID List] [varchar](2048) NULL,
	[BCC  EmailID List] [varchar](2048) NULL,
	[Status] [varchar](2048) NULL,
	[Attachment] [varchar](2048) NULL
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES]') AND parent_object_id = OBJECT_ID(N'[dbo].[BW_PACKAGE_DEPLOYMENT_LOG]'))
ALTER TABLE [dbo].[BW_PACKAGE_DEPLOYMENT_LOG]  WITH CHECK ADD  CONSTRAINT [FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES] FOREIGN KEY([PACKAGE_ID])
REFERENCES [dbo].[BW_DEPLOYED_PACKAGES] ([ID])
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES]') AND parent_object_id = OBJECT_ID(N'[dbo].[BW_PACKAGE_DEPLOYMENT_LOG]'))
ALTER TABLE [dbo].[BW_PACKAGE_DEPLOYMENT_LOG] CHECK CONSTRAINT [FK_BW_PACKAGE_DEPLOYMENT_LOG_BW_DEPLOYED_PACKAGES]
GO


