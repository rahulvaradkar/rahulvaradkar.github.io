USE [BAE_4_7]
GO

/****** Object:  StoredProcedure [dbo].[BW_GET_BCP_OBJECT_LIST_FOR_MIGRATION]    Script Date: 14-06-2022 16:40:06 ******/
DROP PROCEDURE [dbo].[BW_GET_BCP_OBJECT_LIST_FOR_MIGRATION]
GO

/****** Object:  StoredProcedure [dbo].[BW_GET_BCP_OBJECT_LIST_FOR_MIGRATION]    Script Date: 14-06-2022 16:40:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[BW_GET_BCP_OBJECT_LIST_FOR_MIGRATION] 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	SELECT OBJECT_ID, OBJECT_NAME(OBJECT_ID) 'OBJECT_NAME', TYPE, CREATE_DATE, MODIFY_DATE, 
			CONCAT('ObjectId=' , OBJECT_ID , '|' , 'ObjectName=' , OBJECT_NAME(OBJECT_ID) , '|' , 'ObjectType=' , TYPE , '|' , 'COMMAND=CreateSP' , '|' ,  'SEQUENCE=21' )  'PARAMS'   ,
				'CreateSP' 'COMMAND', 21 'SEQUENCE','CUSTOM' PRODUCT_CUSTOM
				FROM SYS.OBJECTS  
					WHERE TYPE='P' 
				AND   OBJECT_NAME(OBJECT_ID) NOT IN (SELECT OBJECT_NAME FROM DATA_DICTIONARY) 
		
				UNION
		
	SELECT OBJECT_ID, OBJECT_NAME(OBJECT_ID) 'OBJECT_NAME', TYPE, CREATE_DATE, MODIFY_DATE, 
			CONCAT('ObjectId=' , OBJECT_ID , '|' , 'ObjectName=' , OBJECT_NAME(OBJECT_ID) , '|' , 'ObjectType=' , TYPE , '|' , 'COMMAND=CreateSP' , '|' ,  'SEQUENCE=21' )  'PARAMS'   ,
				'CreateSP' 'COMMAND', 21 'SEQUENCE','CUSTOM' PRODUCT_CUSTOM
				FROM SYS.OBJECTS  
					WHERE TYPE='U' 
				AND   OBJECT_NAME(OBJECT_ID) NOT IN (SELECT OBJECT_NAME FROM DATA_DICTIONARY) 
				
				UNION

	SELECT OBJECT_ID, OBJECT_NAME(OBJECT_ID) 'OBJECT_NAME', TYPE, CREATE_DATE, MODIFY_DATE, 
			CONCAT('ObjectId=' , OBJECT_ID , '|' , 'ObjectName=' , OBJECT_NAME(OBJECT_ID) , '|' , 'ObjectType=' , TYPE , '|' , 'COMMAND=CreateSP' , '|' ,  'SEQUENCE=21' )  'PARAMS'   ,
				'CreateSP' 'COMMAND', 20 'SEQUENCE','PRODUCT' PRODUCT_CUSTOM
				FROM SYS.OBJECTS ,DATA_DICTIONARY 
					WHERE TYPE='P'  
				AND DATA_DICTIONARY.OBJECT_NAME = OBJECT_NAME(OBJECT_ID)
			
				UNION

	SELECT OBJECT_ID, OBJECT_NAME(OBJECT_ID) 'OBJECT_NAME', TYPE, CREATE_DATE, MODIFY_DATE, 
			CONCAT('ObjectId=' , OBJECT_ID , '|' , 'ObjectName=' , OBJECT_NAME(OBJECT_ID) , '|' , 'ObjectType=' , TYPE , '|' , 'COMMAND=CreateSQLTable' , '|' ,  'SEQUENCE=20' )  'PARAMS'   ,
				'CreateSQLTable' 'COMMAND', 20 'SEQUENCE','PRODUCT' PRODUCT_CUSTOM
				FROM SYS.OBJECTS ,DATA_DICTIONARY
					WHERE TYPE='U' 
			AND DATA_DICTIONARY.OBJECT_NAME = OBJECT_NAME(OBJECT_ID)

END

GO


