from bs4 import BeautifulSoup
import requests
from tkinter import messagebox
import random
import sys

import os
import tkinter as tk
import collections
import tkinter.font as tkFont
from tkinter import messagebox, Frame, font
from tkinter.scrolledtext import ScrolledText
from tkinter import *
import tkinter.ttk as ttk

from tkinter.filedialog import askdirectory
import codecs
import string


col_width = [200, 600, 600]

window = tk.Tk()
max_count = 1

scrape50List = []           #50 Scraped list
revisitedList = []          #Titles that are repeated so not visited list
visitedList = []            #Title of all visited wiki pages
count = 0

nonWikiLinks = []           #Links not visited due to nonWikilink
errorLinks = []             #Error links
typeErrorLinks = []         #Type Error links

dictList = []               #List of dictionaries of all URLS visited the dictionary has title, url, pagecontents, child links
allChildren = []            #List of all unique children links so that visited child is ignored

entryWikiPage = ()          #text box for wikipate address
entryMaxWikiPages = ()      #text box for max wiki pages to iterate
tree = ()                   #treeview widget
lblMessage = ()             #label widget
multilinePageContents = ()  #Multiline Page contents


def btnViewDictionary_click():
    global dictList
    try:
        with open("urlDictionary.txt", "r") as file_in:
            file_contents = file_in.readlines()
            for line in file_contents:
                current_place = line[:-1]
                dictList.append(current_place)
        dictUrls = "\n".join(map(str, dictList))
        # messagebox.showinfo("Display dictionary", dictUrls)
        multilinePageContents.configure(state='normal')
        multilinePageContents.delete("1.0", tk.END)
        multilinePageContents.insert(tk.INSERT, dictUrls)
        multilinePageContents.configure(state='disabled')

    except FileNotFoundError:
        print("File not found. Generating file for first time")
        with open("urlDictionary.txt", "w") as filehandle:
            print("urlDictionary.txt file created.")
            pass


def readUrlDictionaryFromFile():
    global dictList
    dictList = []
    try:
        with open("urlDictionary.txt", "r") as file_in:
            file_contents = file_in.readlines()
            for line in file_contents:
                current_place = line[:-1]
                dictList.append(current_place)
    except FileNotFoundError:
        print("File not found. Generating file for first time")
        with open("urlDictionary.txt", "w") as filehandle:
            print("urlDictionary.txt file created.")
            pass
    print("dictList : ", dictList)


def writeUrlDictionaryToFile():
    global dictList
    with open("urlDictionary.txt", "w") as filehandle:
        filehandle.writelines('%s\n' % place for place in dictList)
    print("Dictionary of URL saved successfully")

def btnGo_click():
    global entryWikiPage, entryMaxWikiPages, max_count, count, lblMessage, tree
    window.config(cursor="wait")
    lblMessage.config(text="Processing... Please wait.")
    window.update_idletasks()
    clearTreeEntries()
    resetVariables()

    # Reading dictionary list of URL from file
    readUrlDictionaryFromFile()

    window.update_idletasks()
    url = entryWikiPage.get()
    max_count = int(entryMaxWikiPages.get())
    count = 0
    scrapeWikiArticle(url)
    tree.tag_configure('visited', background='sky blue')
    tree.tag_configure('link', background='lemon chiffon')
    lblMessage.config(text="Ready")
    window.update_idletasks()
    window.config(cursor="")


def btnClearList_click():
    clearTreeEntries()
    resetVariables()

def clearTreeEntries():
    global tree
    tree.delete(*tree.get_children())

def resetVariables():
    global visitedList, dictList, revisitedList, scrape50List, allChildren
    global count, max_count
    global nonWikiLinks, errorLinks, typeErrorLinks
    global multilinePageContents
    count = 0
    max_count = 0
    visitedList, dictList, revisitedList, scrape50List, allChildren = [[],[],[],[],[]]
    nonWikiLinks, errorLinks, typeErrorLinks = [[],[],[]]
    multilinePageContents.configure(state='normal')
    multilinePageContents.delete("1.0", tk.END)
    multilinePageContents.configure(state='disabled')


def slugify(value):
    print("slugify start value : ", value)
    valid_chars = "-_.() %s%s" %  (string.ascii_letters, string.digits)
    valid_value = ''.join(c for c in value if c in valid_chars)
    print("end of slugify value : " , valid_value)
    return valid_value


def btnSavePages_click():
    global entryWikiPage, entryMaxWikiPages
    global tree
    global dictList

    path = askdirectory()

    for children in tree.get_children():
        # print(tree.item(children)["values"])
        cr = tree.item(children)
        print("cr -> ", cr)

        tag = cr["tags"]

        if ('visited' in tag):  # Displaying page contents
            # Create folder as /titleString to save its linked pages
            foldername = ''
            try:
                foldername = path + "/" + slugify(str(cr["text"]))
                os.mkdir(foldername)
                print("Directory ", foldername, " Created")

            except FileExistsError:
                messagebox.showinfo("Directory exists", foldername + " already exists.")
                print("Directory ", foldername, "already exists")

            # Save pageContent in root as titleString.txt
            filename = path + "/" + slugify(str(cr["text"])) + ".txt"
            text_file = codecs.open(filename, "w", "utf-8")
            text_file.write(cr["values"][1])
            text_file.close()

            child = tree.get_children(children)
            print(children, " :-) ", child)
            totalChildren = len(child)
            counter = 0
            for iid in child:
                counter = counter + 1
                print("child : ", iid)
                cr = tree.item(iid)
                tag = cr["tags"]
                navigate = "https://en.wikipedia.org" + cr["text"]
                lblMessage.config(text="Processing...[" + str(counter) + "/" + str(totalChildren) + "] Please wait. \nReading " + navigate + "")
                window.update_idletasks()
                try:
                    response = requests.get(url=navigate, )
                    soup = BeautifulSoup(response.content, 'html.parser')
                    titleString = soup.title.string
                    pageContent = soup.get_text()
                    # messagebox.showinfo("iid:"+str(iid), pageContent)
                    filename = foldername + "/" + titleString + ".txt"
                    text_file = codecs.open(filename, "w", "utf-8")
                    text_file.write(pageContent)
                    text_file.close()
                    thisUrl = {}
                    thisUrl["title"] = titleString
                    thisUrl["url"] = navigate
                    dictList.append(thisUrl)
                except:
                    e = sys.exc_info()[0]
                    errorMsg = "Error ------> " + str(e)
                    print("errorMsg ---> ", errorMsg)

                lblMessage.config(text="Ready ")
                window.update_idletasks()

    # Writing dictionary list of URL into file
    writeUrlDictionaryToFile()

def selectedItem(event):
    global trees, multilinePageContents, lblMessage
    currItem = tree.focus()
    cr = tree.item(currItem)

    tag = cr["tags"]

    if ('link' in tag):
        # Fetch the page contents of link and display in page contents
        navigate = "https://en.wikipedia.org" + cr["text"]
        lblMessage.config(text="Processing... Please wait. Reading " + navigate + "]")
        window.update_idletasks()

        try:
            response = requests.get(url=navigate,)
            html = response.content
            soup = BeautifulSoup(response.content, 'html.parser')
            titleString = soup.title.string
            pageContent = soup.get_text()
            multilinePageContents.configure(state='normal')
            multilinePageContents.delete("1.0", tk.END)
            multilinePageContents.insert(tk.INSERT, pageContent)
            multilinePageContents.configure(state='disabled')
        except:
            e = sys.exc_info()[0]
            errorMsg = "Error ------> " + str(e)
            multilinePageContents.configure(state='normal')
            multilinePageContents.delete("1.0", tk.END)
            multilinePageContents.insert(tk.INSERT, errorMsg)
            multilinePageContents.configure(state='disabled')

        lblMessage.config(text="Ready ")
        window.update_idletasks()

    elif ('visited' in tag):              # Displaying page contents
        multilinePageContents.configure(state='normal')
        multilinePageContents.delete("1.0", tk.END)
        multilinePageContents.insert(tk.INSERT, cr["values"][1])
        multilinePageContents.configure(state='disabled')


def scrapeWikiArticle(url):
    global entryWikiPage, entryMaxWikiPages, tree
    global count, visitedList, dictList, revisitedList, scrape50List, allChildren
    global tree, max_count
    global nonWikiLinks, errorLinks, typeErrorLinks

    count = count + 1

    if count > max_count:
        sys.exit("Exiting. Counter reached to ", max_count)

    scrape50List.append(url)

    lblMessage.config(text="Processing... Please wait. Adding tree [" + str(count) + "]")
    window.update_idletasks()

    response = requests.get(url=url,)
    html = response.content
    soup = BeautifulSoup(response.content, 'html.parser')
    titleString = soup.title.string
    pageContent = soup.get_text()
    title = soup.find(id="firstHeading")
    print(count, ". Title : ", title.text)

    if title.text in visitedList:           # Revisiting title
        revisitedList.append(title.text)
        return
    else:
        visitedList.append(title.text)

    currId = -1
    currId = tree.insert('', 'end', text=title.text, tags=('visited'))
    tree.set(currId, 'Page Content', soup.get_text())
    tree.set(currId, 'Title', titleString)

    window.update_idletasks()

    allLinks = soup.find(id="bodyContent").find_all("a")
    random.shuffle(allLinks)
    linkToScrape = 0

    childLinks = []
    for link in allLinks:
        try:
            if link["href"].find("/wiki/") == -1:
                nonWikiLinks.append(link)
                continue
            else:
                currchild = "https://en.wikipedia.org" + link['href']
                if currchild not in allChildren:            #check if link is already found, if not, add to childLinks and allChildren
                    childLinks.append(currchild)
                    allChildren.append(currchild)
                    clink = tree.insert(currId, 'end', text=link['href'], tags=('link'))
                    tree.set(clink, 'Links in Topic', link.get('title'))
                    window.update_idletasks()
        except:
            print("Error NonWiki link : ", link)
            errorLinks.append(link)
            continue

    tree.set(currId, 'Links in Topic', len(childLinks))

    thisUrl = {}
    thisUrl["title"] = title.text
    thisUrl["url"] = url
    # thisUrl["content"] = pageContent
    # thisUrl["childLinks"] = childLinks
    print("thisUrl : ", thisUrl)

    dictList.append(thisUrl)

    for link in allLinks:
        # we are interested only other wiki articles
        try:
            if link['href'].find("/wiki/") == -1:
                continue
        except:
            print("Error link : ", link)
            continue

        # User this link to scrape
        linkToScrape = link
        try:
            scrapeWikiArticle("https://en.wikipedia.org" + linkToScrape['href'])
        except:
            e = sys.exc_info()[0]
            typeErrorLinks.append( linkToScrape['href'] )
            print ("Error ------> ", e)
            continue


def displaySoupBowl():
    global entryWikiPage, entryMaxWikiPages, lblMessage, tree , multilinePageContents
    window.geometry('1380x710')
    window.title('WikiPedia Soup Bowl')
    frame = tk.Frame(master=window, width=700, height=690, relief=tk.GROOVE, borderwidth=1)
    frame.pack()

    treeframe = tk.Frame(master=window, width=640, height=690, relief=tk.GROOVE,  borderwidth=1)
    treeframe.pack()

    # WikiPage URL
    lblWikiPageURL = tk.Label(master=frame, text="WikiPage URL :")
    lblWikiPageURL.place(x=10, y=10)

    # Textbox to enter WikiPage url
    entryWikiPage = tk.Entry(master=frame, width=60)
    entryWikiPage.place(x=100, y=10)
    entryWikiPage.delete(0, tk.END)
    entryWikiPage.insert(1, "https://en.wikipedia.org/wiki/Soup")

    # Adding Max WikiPage Links Label
    lblMaxWikiPages = tk.Label(master=frame, text="Max Pages :")
    lblMaxWikiPages.place(x=480, y=10)

    # Textbox entry for Max WikiPages
    entryMaxWikiPages = tk.Entry(master=frame, width=10)
    entryMaxWikiPages.place(x=550, y=10)
    entryMaxWikiPages.delete(0, tk.END)
    entryMaxWikiPages.insert(1, "10")

    # Adding Button to Start WikiPage Scraping
    btnGo = tk.Button(master=frame, text=" Start ", command=btnGo_click)
    btnGo.place(x=625   , y=10)
    btnGo.bind("Click", btnGo_click)

    #Adding treecontrol as treeview
    tree = ttk.Treeview(frame, height=28, columns=('Links in Topic', 'Page Content', 'Title' , 'blank2'), displaycolumns=('Links in Topic', 'Page Content', 'Title', 'blank2'))    # ,  show="tree"

    tree['columns'] = ('Links in Topic', 'Page Content', 'Title', 'blank2')
    tree.column('Links in Topic', width=90, anchor='w')
    tree.column('Page Content', width=1500, anchor='w')
    tree.column('Title', width=100, anchor='w')
    tree.column('blank2', width=100, anchor='w')

    tree.heading('Page Content', text='Page Content')
    tree.heading('Links in Topic', text='Links in Topic')
    tree.heading('Title', text='Title                       ')
    tree.heading('blank2', text='                           ')
    tree.bind('<ButtonRelease-1>', selectedItem)

    tree.pack()

    vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)

    vsb.pack(side='right', fill='y')
    hsb.pack(side='bottom', fill='x')

    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.place(x=10, y=50)

    # Message Label
    lblMessage = tk.Label(master=frame, text="")
    lblMessage.place(x=10, y=640)

    # 'Adding Button to Display Element'
    btnDisplayElement = tk.Button(master=frame, text=" Save Pages to Local Drive ", command=btnSavePages_click)
    btnDisplayElement.place(x=470, y=642)
    btnDisplayElement.bind("Click", btnSavePages_click)

    # Adding Button to Clear List Element
    btnClearList = tk.Button(master=frame, text=" Clear List ", command=btnClearList_click)
    btnClearList.place(x=630, y=642)
    btnClearList.bind("Click", btnClearList_click)

    # Message Label
    fontStyle = tkFont.Font(family='Lucida Grande', size=20)
    lblPageContents = tk.Label(master=treeframe, text="Page Contents", font=fontStyle)
    lblPageContents.place(x=10, y=10)


    # Adding Button to View Dictionary List as messagebox Element
    btnViewDictionary = tk.Button(master=treeframe, text=" View Saved URL Dictionary ", command=btnViewDictionary_click)
    btnViewDictionary.place(x=300, y=10)
    btnViewDictionary.bind("Click", btnViewDictionary_click)

    multilinePageContents = ScrolledText(master=treeframe, bg = '#ffffe6', fg = '#000000', wrap=tk.WORD,  width=65, height=31, padx=10, pady=10, font=("Lucida Grande",  13))
    multilinePageContents.place(x=10, y=50)
    multilinePageContents.configure(state='disabled')

    frame.place(x=10, y=10)
    treeframe.place(x=725, y=10)
    window.mainloop()

displaySoupBowl()

print("dictList : ", dictList)
print("length of dictList : ", len(dictList))
print("visitedList : ", visitedList)
print("length of visitedList : ", len(visitedList))
print("revisitedList : ", revisitedList)
print("length of revisitedList : ", len(revisitedList))
# print("nonWikiLinks : ", nonWikiLinks)
print("length of nonWikiLinks : ", len(nonWikiLinks))
# print("errorLinks : ", errorLinks)
print("length of errorLinks : ", len(errorLinks))
# print("scrape50List : ", scrape50List)
print("length of scrape50List : ", len(scrape50List))
# print("typeErrorLinks : ", typeErrorLinks)
print("length of typeErrorLinks : ", len(typeErrorLinks))


