// this script id injected into the web page so you can access the contents of web page using "document"

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){

    requestType = request[0];

    switch (requestType)
    {
    	case 'search':
		    searchStr = request[1];
		    const re = new RegExp(searchStr,'gi');
		    matches = []
		    matches = document.documentElement.innerHTML.match(re);
		    console.log(matches)
		    if (matches == null)
			    sendResponse({searchCount:  0});
			else
		    	sendResponse({searchCount:  matches.length});
    		
    		break;

    	case 'getElements':
    		tags = request[1];
		    var dict = new Object();
		    var dict = {};

		    tags.forEach(readPageHtml);

		    function readPageHtml(item, index)
		    {
		    	var elem = document.getElementsByTagName(item)
		    	var elemData = []
		    	var allElemData = []
		    	var finalData = []
		    	for(var i=0; i < elem.length; i++)
		    	{
		    		elemData = []
		    		console.log("item " + i + " : " +  elem[i].innerText)
		    		elemData.push(i+1)
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push("")
		    		elemData.push(elem[i].innerText)
		    		allElemData.push(elemData) 
		    	}
		    	finalData.push(allElemData)
		    	dict[item] = finalData
		    }

	    	console.log("JSON.stringify(dict) : " + JSON.stringify(dict) )
			for (const [key, value] of Object.entries(dict)) {
			  console.log(key, value);
			}

		    sendResponse({elementData:  dict});
		    break;
    }

})