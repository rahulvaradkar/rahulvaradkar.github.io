document.addEventListener('DOMContentLoaded',function(){

    document.querySelector('#searchBtn').addEventListener('click',searchBtn_onclick,false)
    document.querySelector('#getElementBtn').addEventListener('click',getElementBtn_onclick,false)


    function searchBtn_onclick(){
        chrome.tabs.query({currentWindow: true, active: true},
            function(tabs){
                console.log("inside function(tabs) of searchBtn_onclick")
                searchString = document.getElementById("searchString").value

                if (searchString.trim() != "")
                {
                    chrome.tabs.sendMessage(tabs[0].id, ['search', searchString], function(response){
                        console.log(response.searchCount)
                        document.getElementById("message").value = response.searchCount
                    });
                }
                else {
                    alert("Enter Search String")
                }
            })
    }

    function getElementBtn_onclick(){
        chrome.tabs.query({currentWindow: true, active: true},
            function(tabs){
                console.log("inside function(tabs) of getElementBtn_onclick ")

                var tags = []

                var checkBoxesSelected = document.querySelectorAll('input[type="checkbox"]:checked');
                var chklength = checkBoxesSelected.length; 

                for (i=0 ; i < checkBoxesSelected.length; i++){
                    tags.push(checkBoxesSelected[i].value)
                }

                if (tags.length == 0)
                    alert("Select Tags to read the page")
                else
                {
                    chrome.tabs.sendMessage(tabs[0].id, ['getElements', tags], function(response){
                        console.log(JSON.stringify(response.elementData))
                        document.getElementById("message").value =  JSON.stringify(response.elementData)
                    });
                }
            })
    }

}, false)