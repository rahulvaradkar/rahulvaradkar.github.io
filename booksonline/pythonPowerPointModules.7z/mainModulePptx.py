# Starting of PPTX reading program
import pptWindow

def main():
    pptWindow.displayPPTViewWindow()


main()