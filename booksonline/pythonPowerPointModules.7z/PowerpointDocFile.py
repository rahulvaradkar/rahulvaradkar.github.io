from pptx import Presentation
from pptx.util import Inches, Pt

from tkinter import messagebox, Frame, font
import sys
import json

class PowerpointDocFile:

    presentation = Presentation()

    def __init__(self, powerpointDoc):
        self.presentation = Presentation(powerpointDoc)

    def printPresentationProperties(self):
        print("--------------------- Presentation Properties Start ----------------------------")
        print("presentation.slide_height : ", self.presentation.slide_height)
        print("presentation.slide_width : ", self.presentation. slide_width)
        print("----------------------- Presentation Properties End --------------------------")

    def printPresentationPropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # messagebox.showinfo("document", self.document)
        self.printPresentationProperties()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printTextFromPresentationSlides(self):
        text_runs = []
        print("slide...shape...text")
        for slide in self.presentation.slides:
            for shape in slide.shapes:
                print("shape.type:", shape.shape_type)

        print("slide...shape...text_frame...paragraph...run.text")
        for slide in self.presentation.slides:
            for shape in slide.shapes:
                if not shape.has_text_frame:
                    continue
                print("shape.text_frame.text:", shape.text_frame.text)
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        text_runs.append(run.text)
        print("text_runs:", text_runs)

    def printTextFromPresentationSlidesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # messagebox.showinfo("document", self.document)
        self.printTextFromPresentationSlides()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data


    def printTablesFromPresentationSlides(self):
        print("slide...shape...table...cell...text")
        for slide in self.presentation.slides:
            for shape in slide.shapes:
                if not shape.has_table:
                    continue
                else:
                    table = shape.table
                    for cell in table.iter_cells():
                        print("cell.text : ", cell.text)

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printTablesFromPresentationSlidesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # redirectOutputToFile
        self.printTablesFromPresentationSlides()
        # redirectOutputToScreen
        # data = readOutputFile
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data

    def printChartsFromPresentationSlides(self):
        print("slide...shape...chart...xxx")
        for slide in self.presentation.slides:
            for shape in slide.shapes:
                if not shape.has_chart:
                    continue
                else:
                    chart = shape.chart
                    print("chart.category_axis : ", chart.category_axis)
                    print("chart.chart_style : ", chart.chart_style)
                    if chart.has_title:
                        print("chart.chart_style : ", chart.chart_style)
                    print("chart.chart_type : ", chart.chart_type)
                    if chart.has_legend:
                        print("chart.legend : ", chart.legend)
                        legend = chart.legend
                        print("legend.font : ", legend.font)
                        print("legend.horz_offset : ", legend.horz_offset)
                        print("legend.include_in_layout : ", legend.include_in_layout)
                        print("legend.position : ", legend.position)

                    print("chart.plots : ", chart.plots)
                    print("chart.replace_data : ", chart.replace_data)
                    print("chart.series : ", chart.series)
                    print("chart.value_axis : ", chart.value_axis)

                    if chart.has_text_frame:
                        print("chart.text_frame.text : ", chart.text_frame.text)

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printChartsFromPresentationSlidesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # redirectOutputToFile
        self.printChartsFromPresentationSlides()
        # redirectOutputToScreen
        # data = readOutputFile
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data



    def printPresentationCoreProperties(self):
        print("--------------------- Presentation Core Properties ----------------------------")
        core_properties = self.presentation.core_properties
        print("core_properties.author : ", core_properties.author)
        print("core_properties.category : ", core_properties.category)
        print("core_properties.comments : ", core_properties.comments)
        print("core_properties.content_status : ", core_properties.content_status)
        print("core_properties.created : ", core_properties.created)
        print("core_properties.identifier : ", core_properties.identifier)
        print("core_properties.keywords : ", core_properties.keywords)
        print("core_properties.language : ", core_properties.language)
        print("core_properties.last_modified_by : ", core_properties.last_modified_by)
        print("core_properties.last_printed : ", core_properties.last_printed)
        print("core_properties.modified : ", core_properties.modified)
        print("core_properties.revision : ", core_properties.revision)
        print("core_properties.subject : ", core_properties.subject)
        print("core_properties.title : ", core_properties.title)
        print("core_properties.version : ", core_properties.version)
        print("---------------------------------------------------------------------------")

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printPresentationCorePropertiesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        # redirectOutputToFile
        self.printPresentationCoreProperties()
        # redirectOutputToScreen
        # data = readOutputFile
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data


    def printPresentationSlidelayouts(self):
        print("--------------------- Presentation SlideLayouts Properties ----------------------------")
        slide_layouts = self.presentation.slide_layouts
        for layout in slide_layouts:
            print("===========================================================")
            print("slide_layouts.part : ", layout.part)
            print("slide_layouts.shapes : ", layout.shapes)
            for shape in layout.shapes:
                if not shape.has_text_frame:
                    continue
                print("=====>> shape.text : ", shape.text)
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        print("------> shape.paragraph.run : ", run.text)

            print("slide_layouts.placeholders : " , layout.placeholders)
            print("slide_layouts.slide_master : " , layout.slide_master)
            print("slide_layouts.used_by_slides : " , layout.used_by_slides)
            print("===========================================================")
        print("---------------------------------------------------------------------------------------")

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printPresentationSlidelayoutsStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printPresentationSlidelayouts()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data


    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printPresentationSlides(self):
        print("--------------------- Presentation Slides Properties Start ----------------------------")

        slides = {}
        currSlide = {}

        slideCount = 0
        for slide in self.presentation.slides:
            currSlide = {}
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            slideCount += 1
            # print("slide.name : " , slide.name)
            print("slide.id : " , slide.slide_id)
            currSlide["SlideId"] = slide.slide_id
            print("slide.has_notes_slide : ", slide.has_notes_slide)
            if slide.has_notes_slide:
                note_slide = slide.notes_slide
                # print("note_slide.background : ", note_slide.background)
                # print("note_slide.element : ", note_slide.element)
                # print("note_slide.name : ", note_slide.name)
                # print("note_slide.notes_placeholder : ", note_slide.notes_placeholder)
                # print("note_slide.notes_text_frame : ", note_slide.notes_text_frame)

                for paragraph in note_slide.notes_text_frame.paragraphs:
                    for run in paragraph.runs:
                        print("----> run.text : ", run.text)

                currSlide["SlideNote"] = note_slide.notes_text_frame.text

                # print("note_slide.part : ",  note_slide.part)
                # print("note_slide.placeholders : ", note_slide.placeholders)
                # print("note_slide.shapes : ", note_slide.shapes)
            else:
                currSlide["SlideNote"] = ""

            slide_shapes = []
            for shape in slide.shapes:
                if not shape.has_text_frame:
                    slide_shapes.append("")
                    continue
                for paragraph in shape.text_frame.paragraphs:
                    print("------> shape.paragraph.text : ", paragraph.text)
                    for run in paragraph.runs:
                        print("------> shape.paragraph.run : ", run.text)
                slide_shapes.append(shape.text_frame.text)

            currSlide["Shape Text"] = slide_shapes
            slides["Slide " + str(slideCount)] = currSlide

        print("json.dumps(slides)")
        print(json.dumps(slides))
        print("--------------------- Presentation Slides Properties End ----------------------------")
        return slides

    # Print the properties to pythonCallOutput.txt file , and returns entire contents of that result.
    def printPresentationSlidesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printPresentationSlides()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data


    def printPresentationTables(self):
        print("--------------------- Presentation Table Properties Start ----------------------------")
        for slide in self.presentation.slides:
            for shape in slide.shapes:
                if not shape.has_table:
                    continue
                else:
                    table = shape.table
                    for cell in table.iter_cells():
                        print("cell.text : ", cell.text)
        print("--------------------- Presentation Table Properties End ----------------------------")


    def printPresentationTablesStdOut(self):
        old_stdout = sys.stdout
        sys.stdout = open("pythonCallOutput.txt", "w")
        self.printPresentationTables()
        sys.stdout.close()
        file1 = open("pythonCallOutput.txt", "r")
        data = file1.read()
        file1.close()
        sys.stdout = old_stdout
        return data
