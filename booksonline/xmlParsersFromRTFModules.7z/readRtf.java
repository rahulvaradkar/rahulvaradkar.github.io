//e:\tika\javax.xml-1.3.4.jar;
//e:\tika\w3c-dom.jar;
//e:\tika\rtfparserkit.jar;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
//import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.rtfparserkit.converter.text.StringTextConverter;
import com.rtfparserkit.parser.RtfStreamSource;

public class readRtf {

	private JFrame frame;
	private JLabel lblMessage;
	private JComboBox cbolist;
	private JButton btnNewButton ;
	private JTextArea txtRtfFileSource;
	private JTextArea txtRtfFileContents;
	private JTextArea txtXpaths;

	private JTextArea xPathText;
	private JTextArea xPathResult;
	
	int TXT_HEIGHT = 480;

	DocumentBuilderFactory factory;
	DocumentBuilder builder;
	InputSource is;
	Document doc;
	XPathFactory xpathfactory;
	XPath xpath;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					readRtf window = new readRtf(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public String readRtfFile(String filepathname)
	{
		String extractedText = null;
		try 
		{
			InputStream is = new FileInputStream(filepathname);
			StringTextConverter converter = new StringTextConverter();
			converter.convert(new RtfStreamSource(is));
			extractedText = converter.getText();
			
			int startPos = extractedText.indexOf("<?xml");  
			  
			extractedText = extractedText.substring(startPos);
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return extractedText;
	}
	
	
	/**
	 * Create the application.
	 */
	public readRtf(String extractedText) {
		initialize(extractedText);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String extractedText) {
		frame = new JFrame("Processing RTF file");
		frame.setBounds(100,100,1200,800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null );
		btnNewButton = new JButton("Select File");
		btnNewButton.setToolTipText("This is button");

		btnNewButton.setForeground(new Color(51, 0 , 51));
		btnNewButton.setBackground(new Color(255, 255 , 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD , 12));
		btnNewButton.setBounds(10, 500, 123, 23);
		frame.getContentPane().add(btnNewButton);

		txtRtfFileSource = new JTextArea();
		txtRtfFileSource.setForeground(new Color(51, 0, 51));
		txtRtfFileSource.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtRtfFileSource.setBackground(Color.GREEN);
		txtRtfFileSource.setBounds(10, 20, 345, TXT_HEIGHT);
	
		JScrollPane rtffile = new JScrollPane(txtRtfFileSource);
		rtffile.setForeground(new Color(51, 0 , 51));
		rtffile.setBackground(new Color(0, 255 , 0));
		rtffile.setFont(new Font("Tahoma", Font.BOLD , 12));
		rtffile.setBounds(10, 20, 345, TXT_HEIGHT);

		frame.getContentPane().add(rtffile);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser jfc = new JFileChooser();
				StringBuilder sb = new StringBuilder();
				File file ;
				
				if (jfc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
				{
					file = jfc.getSelectedFile();
					
					lblMessage.setText(file.getAbsolutePath());
					
					Scanner input;
					try {
						input = new Scanner(file);
						while (input.hasNext())
						{
							sb.append(input.nextLine());
							sb.append("\n");
							
						}
						input.close();
						
						
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					String extractedText = readRtfFile(file.getAbsolutePath());
					
					txtRtfFileContents.setText(extractedText);

					GetXPathsFromXml(txtRtfFileContents.getText());
					
					
				}
				else
				{
					lblMessage.setText("No file was selected.");
					sb.append("No file was selected.");
				}
				txtRtfFileSource.setText(sb.toString());
			}
		} );
		
		
		cbolist = new JComboBox();
		cbolist.setForeground(new Color(51, 0 , 51));
		cbolist.setBackground(new Color(0, 255 , 0));
		cbolist.setFont(new Font("Tahoma", Font.BOLD , 12));
		cbolist.setBounds(10, 525, 1150, 23);
		frame.getContentPane().add(cbolist);

		cbolist.addItemListener(new ItemListener() {
		    public void itemStateChanged(ItemEvent ie) {
		    	 if (ie.getStateChange() == ItemEvent.SELECTED)
		    	 {
		    		 parseXmlUsingXPath((String) ie.getItem());
		    	 }
		    	 else
		    	 {
		    	 }
		    }
		});
		
		
		lblMessage = new JLabel("filename : ");
		lblMessage.setBounds(10, 0, 400, 23);
		frame.getContentPane().add(lblMessage);

		txtRtfFileContents = new JTextArea();
		txtRtfFileContents.setForeground(new Color(51, 0 , 51));
		txtRtfFileContents.setBackground(new Color(0, 255 , 0));
		txtRtfFileContents.setFont(new Font("Tahoma", Font.BOLD , 12));
		txtRtfFileContents.setBounds(400, 20, 345, TXT_HEIGHT);
		txtRtfFileContents.setText(extractedText);
		
		JScrollPane sp = new JScrollPane(txtRtfFileContents);
		sp.setForeground(new Color(51, 0 , 51));
		sp.setBackground(new Color(0, 255 , 0));
		sp.setFont(new Font("Tahoma", Font.BOLD , 12));
		sp.setBounds(400, 20, 345, TXT_HEIGHT);

		frame.getContentPane().add(sp);
		
		txtXpaths = new JTextArea();
		txtXpaths.setForeground(new Color(51, 0, 51));
		txtXpaths.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtXpaths.setBackground(Color.GREEN);
		txtXpaths.setBounds(800, 20, 345, TXT_HEIGHT);
	
		JScrollPane xpath = new JScrollPane(txtXpaths);
		xpath.setForeground(new Color(51, 0 , 51));
		xpath.setBackground(new Color(0, 255 , 0));
		xpath.setFont(new Font("Tahoma", Font.BOLD , 12));
		xpath.setBounds(800, 20, 345, TXT_HEIGHT);

		frame.getContentPane().add(xpath);
				

		JButton btnNewButton_1 = new JButton("Parse XML");   // should discontinue this as GetXPathFromXml is called when file is selected and displayed
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Doing nothing");
			}
		});
		btnNewButton_1.setForeground(new Color(51, 0, 51));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBackground(Color.GREEN);
		btnNewButton_1.setBounds(400, 500, 123, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblXmlInRtf = new JLabel("XML in RTF");
		lblXmlInRtf.setBounds(400, 0, 172, 23);
		frame.getContentPane().add(lblXmlInRtf);
		
		JLabel lblXpathsInXml = new JLabel("XPATHS in XML");
		lblXpathsInXml.setBounds(800, 0, 172, 23);
		frame.getContentPane().add(lblXpathsInXml);

		
		JButton btnXpathButton = new JButton("Get XPATH");
		btnXpathButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Enter XPATH HERE");
				System.out.println("before parseXmlUsingXPath");
				parseXmlUsingXPath(null);
				System.out.println("after parseXmlUsingXPath");
			}
		});
		btnXpathButton.setForeground(new Color(51, 0, 51));
		btnXpathButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnXpathButton.setBackground(Color.GREEN);
		btnXpathButton.setBounds(1000, 500, 123, 23);
		frame.getContentPane().add(btnXpathButton);

		xPathText = new JTextArea();
		xPathText.setForeground(new Color(51, 0, 51));
		xPathText.setFont(new Font("Tahoma", Font.BOLD, 12));
		xPathText.setBackground(Color.YELLOW);
		xPathText.setBounds(550, 500, 500, 23);
	
		frame.getContentPane().add(xPathText);

		
		xPathResult  = new JTextArea();
		xPathResult.setForeground(new Color(51, 0, 51));
		xPathResult.setFont(new Font("Tahoma", Font.BOLD, 12));
		xPathResult.setBackground(Color.GREEN);
		xPathResult.setBounds(800, 550, 345, TXT_HEIGHT);

		
		JScrollPane xpathResult = new JScrollPane(xPathResult);
		xpathResult.setForeground(new Color(51, 0 , 51));
		xpathResult.setBackground(new Color(0, 255 , 0));
		xpathResult.setFont(new Font("Tahoma", Font.BOLD , 12));
		xpathResult.setBounds(800, 550, 345, TXT_HEIGHT);

		frame.getContentPane().add(xpathResult);

	}
	
	public void GetXPathsFromXml(String xmlString)
	{
		readXmlIntoParser();
		
		try 
		{


			txtXpaths.setText("");

	        xmlParser parser = new xmlParser();
	        
	        //Parse the file
	
	        parser.parseXml(new InputSource(new StringReader(xmlString)));
	        
	        //Verify the result
	        System.out.println("Done");
	
	        Iterator<String> itr;
	        itr = parser.getUniquePaths();
	
	        System.out.println("Inside TestXmlSaxParser Unique Paths : ");
	
	        int i = 0;
	        
	        String cboele;
	        
	        cbolist.removeAllItems();
	        
	        while(itr.hasNext())
	        {  
	           // System.out.println("Unique Paths " + i + " : " + itr.next());  
	            i=i+1;
	            cboele = "/" + itr.next() + "/text()";
				txtXpaths.setText(txtXpaths.getText() + "\n" + i +  ": " + cboele);
				
				
				System.out.println("checkXPath(cboele) .............@-" + cboele + "-@-" + checkXPath(cboele) + "-@");
				
				if (!checkXPath(cboele).trim().isEmpty())
				{
					System.out.println("Adding ..... checkXPath(cboele) -> " + checkXPath(cboele));
					cbolist.addItem(cboele);
				}
	        }  
		}
        catch(SAXException sax)
        {
			txtXpaths.setText("Error : " + sax.getMessage());
        }
	}
	
	
	public void readXmlIntoParser()
	{
		
		try 
		{
		     System.out.println("Doneeeeeeeeeeeeeeeee 1 !!!!");

		     factory = DocumentBuilderFactory.newInstance();
			 factory.setNamespaceAware(true); // never forget this!
			 builder = factory.newDocumentBuilder();
	
		     System.out.println("Doneeeeeeeeeeeeeeeee 2 !!!!");

			 is = new InputSource();
			 System.out.println(txtRtfFileContents.getText());
			 is.setCharacterStream(new StringReader(txtRtfFileContents.getText()));

		     System.out.println("Doneeeeeeeeeeeeeeeee 3 !!!!");

			 doc = (Document) builder.parse(is);

		     System.out.println("Doneeeeeeeeeeeeeeeee 4 !!!!");

			//Create XPath
			 
			 xpathfactory = XPathFactory.newInstance();
		     xpath = xpathfactory.newXPath();

		     System.out.println("Doneeeeeeeeeeeeeeeee 5 !!!!");

		     System.out.println("Doneeeeeeeeeeeeeeeee 5.1 !!!!" +  xPathText.getText());
		     
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("Doneeeeeeeeeeeeeeeee 8 !!!!");
		}
		
		
	}
	
	public String checkXPath(String srchPath)
	{
	     StringBuffer resultStr = new StringBuffer();
		try 
		{
		     XPathExpression expr = xpath.compile(srchPath);
		     Object result = expr.evaluate(doc, XPathConstants.NODESET);
		     NodeList nodes = (NodeList) result;
	
		     System.out.println("Doneeeeeeeeeeeeeeeee 6 !!!!");
	
		     
		     for (int i = 0; i < nodes.getLength(); i++) 
		     {
		    	 System.out.println(nodes.item(i).getNodeValue());

		    	 if (nodes.item(i).getNodeValue() != null && !nodes.item(i).getNodeValue().isEmpty())
		    		 resultStr.append(nodes.item(i).getNodeValue() + "\n");
		    	 
		     }
		     System.out.println("Doneeeeeeeeeeeeeeeee 7 !!!!");

		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("Doneeeeeeeeeeeeeeeee 8 !!!!");
		}
	     return resultStr.toString().trim();
	}
	
	public void parseXmlUsingXPath(String xPath)
	{
		try 
		{
		     System.out.println("Doneeeeeeeeeeeeeeeee 1 !!!!");

		     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			 factory.setNamespaceAware(true); // never forget this!
			 DocumentBuilder builder = factory.newDocumentBuilder();
	
		     System.out.println("Doneeeeeeeeeeeeeeeee 2 !!!!");

			 InputSource is = new InputSource();
			 System.out.println(txtRtfFileContents.getText());
			 is.setCharacterStream(new StringReader(txtRtfFileContents.getText()));

		     System.out.println("Doneeeeeeeeeeeeeeeee 3 !!!!");

			 Document doc = (Document) builder.parse(is);

		     System.out.println("Doneeeeeeeeeeeeeeeee 4 !!!!");

			//Create XPath
			 
			 XPathFactory xpathfactory = XPathFactory.newInstance();
		     XPath xpath = xpathfactory.newXPath();

		     System.out.println("Doneeeeeeeeeeeeeeeee 5 !!!!");

		     System.out.println("Doneeeeeeeeeeeeeeeee 5.1 !!!!" +  xPathText.getText());
		     System.out.println("Doneeeeeeeeeeeeeeeee 5.2 !!!!" +  xPath);
		     
		     String srchPath;
		     if (xPath == null)
		    	 srchPath = xPathText.getText();
	    	 else
	    		 srchPath = xPath;
		    		 
		     XPathExpression expr = xpath.compile(srchPath);
		     Object result = expr.evaluate(doc, XPathConstants.NODESET);
		     NodeList nodes = (NodeList) result;

		     System.out.println("Doneeeeeeeeeeeeeeeee 6 !!!!");

		     StringBuffer resultStr = new StringBuffer();
		     
		     for (int i = 0; i < nodes.getLength(); i++) 
		     {
		    	 System.out.println("xxxxx" + nodes.item(i).getNodeValue().trim() + "yyyyyyyyy");
		    	 
		    	 if (!nodes.item(i).getNodeValue().trim().isEmpty())
		    		 resultStr.append(nodes.item(i).getNodeValue().trim() + "\n");
		     }
		     xPathResult.setText(resultStr.toString());
		     System.out.println("Doneeeeeeeeeeeeeeeee 7 !!!!");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("Doneeeeeeeeeeeeeeeee 8 !!!!");
		}
		
		
	}
	
}

