# Starting of Python program
import placeGeometry

def main():
    placeGeometry.displayFileViewWindow()

main()
