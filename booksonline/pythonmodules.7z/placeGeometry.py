import os
import tkinter as tk
from tkinter import messagebox, Frame, font
from tkinter.filedialog import askopenfilename
from tkinter.scrolledtext import ScrolledText
from tkinter import *
from FrameworkSettings import FrameworkSettings
from WordDocFile import WordDocFile
import WordDocFile

window = tk.Tk()

headingList = []
pythonCallList = []
propertiesList = []
wdf = ()

# Dictionary returned by wdf.getParagraphList()
paraDict = {}
paraIndex = []
paraText = []
paraRuns = []

def displayFileViewWindow():

    wordDocument = -1
    HeadingIndex = -1
    PropertiesIndex = -1

    # Display Row Data Extracted from Word Document. This include Paragraph, Runs, Text, Font Details etc.
    def lblShowRawDataExtractClick(evt):
        global wdf
        global paraDict

        if isinstance(wdf, WordDocFile.WordDocFile ):
            paraDict = wdf.getParagraphList()
            # messagebox.showinfo("fullText", docText)
            multilineContents.delete("1.0", tk.END)
            multilineContents.insert(tk.INSERT, paraDict)
        else:
            messagebox.showinfo("Word Document not Selected", "You must Select the Word Document to Display the Extracted Raw Data.")


    def lblShowWordDocContentClick(evt):    #When Display File Content label is clicked
        global wdf
        if isinstance(wdf, WordDocFile.WordDocFile ):
            displayTextInWordDocument()
        else:
            messagebox.showinfo("Word Document not Selected", "You must Select the Word Document to Display the Contents.")

    def setSingleSelectProperty(evt):       #Turns Clicked Label bg to Black
        # Note here that Tkinter passes x`an event object to onLstHeadingSelect()
        w = evt.widget
        w.config(bg="black")
        w.config(fg="white")
        lblText = w.cget("text")
        if lblText == " Single ":
            lblMulti.config(bg="white")
            lblMulti.config(fg="black")
            lstProperties.config(selectmode=SINGLE)
        elif lblText == " Multi ":
            lblSingle.config(bg="white")
            lblSingle.config(fg="black")
            lstProperties.config(selectmode=MULTIPLE)

    # Display Message Box function equivalant to VBA masgbox
    def msgbox (header, message):
        messagebox.showinfo(header, message)

    def displaySelectedPropertyHelpText(headingText, propertiesText):
        currElementNote = {}
        headingIndex = lstHeadings.curselection()[0]
        currElementNote = propertiesList[headingIndex]["notes"]
        elementIndex = lstProperties.curselection()[0]
        print("currElementNote", currElementNote)

        curr_Note = currElementNote[elementIndex]

        multilineHelp.configure(state='normal')
        multilineHelp.delete("1.0", tk.END)
        multilineHelp.insert(tk.INSERT, curr_Note)
        multilineHelp.configure(state='disabled')

    def onPropertiesElementSelection(index):
        propertiesText = lstProperties.get(index)
        headingText = lstHeadings.get(lstHeadings.curselection()[0])
        displaySelectedPropertyHelpText (headingText, propertiesText)

    # Selection of Paragraph. Called from lstParas select Event with Index of selected element
    def onParasElementSelection(index):
        global paraText
        global paraRuns
        print("Inside onParasElementSelection")
        # messagebox.showinfo("index in onParasElementSelection", index)
        # messagebox.showinfo("paraText", paraText)
        # messagebox.showinfo("para text", paraText[index])

        # Displaying Paragraph Text of selected Paragraph
        multilineParaText.configure(state='normal')
        multilineParaText.delete("1.0", tk.END)
        multilineParaText.insert(tk.INSERT, paraText[index])
        multilineParaText.configure(state='disabled')

        # Displaying Run Details of Selected Paragraph
        currRunData = paraRuns[index]
        runCount = currRunData["runCount"]
        runDetails = currRunData["runDetails"]

        # messagebox.showinfo("current runCount                   ", runCount)
        # messagebox.showinfo("current runDetails                 ", runDetails)
        # Listing all Paragraph Runs
        lstParaRuns.delete(0, END)
        for run in runCount:
            print("Run item : ", run)
            lstParaRuns.insert(END, run)

        # Clearing RunDetails in Multiline textbox
        multilineRunDetails.configure(state='normal')
        multilineRunDetails.delete("1.0", tk.END)
        multilineRunDetails.configure(state='disabled')


    # Called from lstHeading select Event with Index of selected element
    def onHeadingElementSelection(index):
        print("PropertyElement", propertiesList[index] )
        currElementDict = {}
        currElementDict = propertiesList[index]["element"]
        currPythonCall = pythonCallList[index]
        print("element", currElementDict)

        if isinstance(wdf, WordDocFile.WordDocFile ):
            result = getattr(wdf, currPythonCall)()
        else:
            messagebox.showinfo("Select Word Document", "Word document is not selected. Select Word Document.")
            result = ""

        multilineDocProperty.configure(state='normal')
        multilineDocProperty.delete("1.0", tk.END)
        multilineDocProperty.insert(tk.INSERT, result)
        multilineDocProperty.configure(state='disabled')

        # Adding Properties into listbox
        lstProperties.delete(0, END)
        for item in currElementDict:
            print("headingList item : ", item)
            lstProperties.insert(END, item)

    # Called when element in lstProperties listbox is selected
    def onLstPropertiesSelect(evt):
        # Note here that Tkinter passes an event object to onLstHeadingSelect()
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        onPropertiesElementSelection(index)

    # Called when element in Paragraph Runs listbox is selected
    def onLstParaRunsSelect(evt):
        global paraRuns
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        # messagebox.showinfo("value", value)
        multilineRunDetails.delete("1.0", tk.END)
        paraSelected = -1
        paraSelected = int(lstParas.curselection()[0])
        currRunData = paraRuns[paraSelected]
        runCount = currRunData["runCount"]
        runDetails = {}
        runDetails = currRunData["runDetails"][index]

        for x, y in runDetails.items():
            print("runDetails: x y => ", x, y)

        # Displaying selected RunDetails in Multiline textbox
        multilineRunDetails.configure(state='normal')
        multilineRunDetails.delete("1.0", tk.END)
        multilineRunDetails.insert(tk.INSERT, runDetails)
        multilineRunDetails.configure(state='disabled')

    # Called when element in lstParas listbox is selected
    def onLstParasSelect(evt):
        # Note here that Tkinter passes an event object to onLstParasSelect()
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        # messagebox.showinfo("value", value)
        onParasElementSelection(index)


    # Called when element in lstHeading listbox is selected
    def onLstHeadingSelect(evt):
        # Note here that Tkinter passes an event object to onLstHeadingSelect()
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        onHeadingElementSelection(index)

    # Not used. multilineContents is not used
    def displayFileContents(filename):
        file1 = open(filename, "r")
        data = file1.read()
        multilineContents.delete("1.0", tk.END)
        multilineContents.insert(tk.INSERT, data)
        file1.close()

    # Displaying List of Paragraphs in Word Document in lstPara
    def displayParagraphListInWordDocument():
        global wdf
        global paraText
        global paraIndex
        global paraRuns
        global paraDict

        if isinstance(wdf, WordDocFile.WordDocFile ):
            paraDict = wdf.getParagraphList()
            print("paraDict : ", paraDict)
            paraIndex = paraDict["paraIndex"]
            paraText = paraDict["paraText"]
            paraRuns = paraDict["paraRuns"]

            print("paraText : ", paraText)

            # messagebox.showinfo("paraText : ", paraText)
            # messagebox.showinfo("paraIndex: ", paraIndex)
            # messagebox.showinfo("paraRuns : ", paraRuns)

            lstParas.delete(0, END)
            # Adding Paragraphs into listbox
            paraCount = 0
            for item in paraIndex:
                paraCount += 1
                print("paraList item : ", paraCount)
                lstParas.insert(END, "Paragraph {0} ".format(paraCount))
        else:
            lstParas.delete(0, END)

    def displayTextInWordDocument():
        global wdf
        if isinstance(wdf, WordDocFile.WordDocFile ):
            docText = wdf.getDocumentText()
            # messagebox.showinfo("fullText", docText)
            multilineContents.delete("1.0", tk.END)
            multilineContents.insert(tk.INSERT, docText)
        else:
            multilineContents.delete("1.0", tk.END)
            multilineContents.insert(tk.INSERT, "")

    def btnSelectDocument_click():
        print("Select Word Document from local drive.")
        filename = askopenfilename()  # show an "Open" dialog box and return the path to the selected file
        print(filename)
        entryFileName.delete(0, tk.END)
        entryFileName.insert(1, filename)
        # displayFileContents(filename)
        global wdf
        wdf = WordDocFile.WordDocFile(filename)
        data = wdf.printDocumentPropertiesStdOut()
        # Displaying data in multilineDocProperty
        multilineDocProperty.configure(state='normal')
        multilineDocProperty.delete("1.0", tk.END)
        multilineDocProperty.insert(tk.INSERT, data)
        multilineDocProperty.configure(state='disabled')
        displayTextInWordDocument()
        displayParagraphListInWordDocument()

    window.geometry('1200x750')
    window.title('Capture Word Document')

    frame = tk.Frame(master=window, width=1200, height=720, relief=tk.GROOVE, borderwidth=1)
    frame.pack()

    # Filename label
    lblWordDocument = tk.Label(master=frame, text="Word Document :")
    lblWordDocument.place(x=10, y=10)

    # Textbox to display selected filename
    entryFileName = tk.Entry(master=frame, width=100)
    entryFileName.place(x=110, y=10)

    # Adding Contents Label
    lblContents = tk.Label(master=frame, text="Contents :")
    lblContents.place(x=12, y=500)

    # Adding Multiline Textbox to Display Contents of File
    multilineContents = ScrolledText(master=frame, wrap=tk.WORD, width=145, height=12, padx=10, pady=10, font=("Tahoma", 8))
    multilineContents.place(x=12, y=520)

    # Adding Display File Contents Label, when clicked it Displays Text in Selected Word Document
    lblShowWordDocContent = tk.Label(master=frame, text="Display File Contents", bg="black", fg="white", underline=0)
    lblShowWordDocContent.place(x=700, y=497)
    lblShowWordDocContent.bind("<Button-1>", lblShowWordDocContentClick )

    fs = FrameworkSettings()

    cwd = os.getcwd()
    cwd = cwd + "\\" + "FrameworkForWordDocument.xlsx"
    # msgbox("cwd", cwd)

    fs.loadFrameworkSettings(cwd, "R")

    settingDict = {}
    settingDict = fs.processRowWiseElements()
    print("settingDict In mainModule() : ", settingDict)

    headingList = settingDict["Heading"]
    pythonCallList = settingDict["PythonCall"]
    propertiesList = settingDict["Details"]

    # create listbox Label
    lblHeading = tk.Label(master=frame, text="Headings :")
    lblHeading.place(x=12, y=40)

    # create Heading listbox control
    lstHeadings = Listbox(master=frame, height=10,
                      width=35,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstHeadings.bind('<<ListboxSelect>>', onLstHeadingSelect)
    lstHeadings.place(x=12, y=60)
    lstHeadings.delete(0, END)

    # Adding Headings into listbox
    for item in headingList:
        print("headingList item : ", item)
        lstHeadings.insert(END, item)

    # Setting Scrollbar to listbox .....NOT WORKING
    scrollbar = Scrollbar(master=lstHeadings)
    lstHeadings.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=lstHeadings.yview)

    # create Properties listbox Label
    lblProperties = tk.Label(master=frame, text="Properties :")
    lblProperties.place(x=250, y=40)

    lblSingle = tk.Label(master=frame, text=" Single ", bg='black', fg='yellow', underline=8, highlightbackground='green', borderwidth=1, relief="groove")
    lblSingle.place(x=450, y=40)
    lblSingle.bind("<Button-1>", setSingleSelectProperty)

    lblMulti = tk.Label(master=frame, text=" Multi ", bg='white', fg='black', underline=7, highlightbackground='green', borderwidth=1, relief="groove")
    lblMulti.place(x=500, y=40)
    lblMulti.bind("<Button-1>", setSingleSelectProperty)

    # create Properties listbox control
    lstProperties = Listbox(master=frame, height=10,
                        width=50,
                        bg="white",
                        activestyle='dotbox',
                        fg="black",
                        selectmode="multiple")

    lstVsb = tk.Scrollbar(frame, orient="vertical", command=lstProperties.yview)
    lstHsb = tk.Scrollbar(frame, orient="horizontal", command=lstProperties.xview)
    lstProperties.configure(yscrollcommand=lstVsb.set, xscrollcommand=lstHsb.set)

    lstProperties.config(selectmode=SINGLE)
    lstProperties.bind('<<ListboxSelect>>', onLstPropertiesSelect)

    lstProperties.place(x=250, y=60)
    lstProperties.delete(0, END)

    # Adding Multiline Help Textbox to Display Help Information
    # create Properties Description Label
    lblPropertyDesc = tk.Label(master=frame, text="Description :")
    lblPropertyDesc.place(x=570, y=40)

    multilineHelp = ScrolledText(master=frame, bg = '#ffffe6', fg = '#000000', wrap=tk.WORD,  width=45, height=10, padx=10, pady=10, font=("Tahoma",  10))
    multilineHelp.place(x=570, y=60)
    multilineHelp.configure(state='disabled')

    # Adding label and Textbox to display Paragraph List in Word Document
    lblParagraphs = tk.Label(master=frame, text="Paragraph List :")
    lblParagraphs.place(x=930, y=40)

    # Adding listbox to list all Paragraphs in the docuemnt
    lstParas = Listbox(master=frame, height=10,
                      width=25,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstParas.bind('<<ListboxSelect>>', onLstParasSelect)
    lstParas.place(x=930, y=60)
    lstParas.delete(0, END)

    # Adding label and Textbox to display Paragraph List in Word Document
    lblParaText = tk.Label(master=frame, text="Paragraph Text :")
    lblParaText.place(x=930, y=220)

    # Displaying selected Paragraph Text
    multilineParaText = ScrolledText(master=frame, wrap=tk.WORD, bg = '#ffffe6', fg = '#000000',  width=25, height=5, padx=10, pady=10, font=("Tahoma",  10))
    multilineParaText.place(x=930, y=240)
    multilineParaText.configure(state='disabled')

    # Adding Run Details information
    # Adding label and Textbox to display Runs list in Paragraph in Word Document
    lblRuns = tk.Label(master=frame, text="Paragraph Runs :")
    lblRuns.place(x=930, y=340)

    # Adding listbox to list all Run in the selected paragraph
    lstParaRuns = Listbox(master=frame, height=5,
                      width=25,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstParaRuns.bind('<<ListboxSelect>>', onLstParaRunsSelect)
    lstParaRuns.place(x=930, y=360)
    lstParaRuns.delete(0, END)

    # Adding label and Textbox to display Runs list in Paragraph in Word Document
    lblRunDetail = tk.Label(master=frame, text="Runs Details :")
    lblRunDetail.place(x=930, y=445)

    # Displaying selected Run Details information
    multilineRunDetails = ScrolledText(master=frame, wrap=tk.WORD, bg = '#ffffe6', fg = '#000000',  width=25, height=5, padx=10, pady=10, font=("Tahoma",  10))
    multilineRunDetails.place(x=930, y=465)
    multilineRunDetails.configure(state='disabled')

    # Adding Paragraph Text Properties , when clicked it Displays Paragraph-wise Run Properties of Word Document
    lblShowRawDataExtract = tk.Label(master=frame, text="Display Raw Data Extract", bg="black", fg="white", underline=0, borderwidth=1, relief="groove")
    lblShowRawDataExtract.place(x=930, y=570)
    lblShowRawDataExtract.bind("<Button-1>", lblShowRawDataExtractClick )

    #

    # Adding label and Textbox to display selected properties of Word Document
    lblDocumentProperty = tk.Label(master=frame, text="Selected Properties")
    lblDocumentProperty.place(x=12, y=250)

    multilineDocProperty = ScrolledText(master=frame, wrap=tk.WORD, bg = '#ffffe6', fg = '#000000',  width=125, height=12, padx=10, pady=10, font=("Tahoma",  10))
    multilineDocProperty.place(x=12, y=280)
    multilineDocProperty.configure(state='disabled')

    textVsb = tk.Scrollbar(frame, orient="vertical", command=multilineDocProperty.yview)
    textHsb = tk.Scrollbar(frame, orient="horizontal", command=multilineDocProperty.xview)
    multilineDocProperty.configure(yscrollcommand=textVsb.set, xscrollcommand=textHsb.set)

    # 'Adding Button to Select Document'
    btnSelectDocument = tk.Button(master=frame, text="Select Word Document", command=btnSelectDocument_click)
    btnSelectDocument.place(x=720, y=10)
    btnSelectDocument.bind("Click", btnSelectDocument_click)

    frame.place(x=10, y=10)
    lstHeadings.select_set(0)
    window.mainloop()


