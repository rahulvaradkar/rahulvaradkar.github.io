import os
import tkinter as tk
from tkinter import messagebox, Frame, font
from tkinter.filedialog import askopenfilename
from tkinter.scrolledtext import ScrolledText
from tkinter import *
from FrameworkSettings import FrameworkSettings
from WordDocFile import WordDocFile
import WordDocFile

window = tk.Tk()

headingList = []
pythonCallList = []
propertiesList = []
wdf = ()

def displayFileViewWindow():

    wordDocument = -1
    HeadingIndex = -1
    PropertiesIndex = -1

    def setSingleSelectProperty(evt):       #Turns Clicked Label bg to Black
        # Note here that Tkinter passes x`an event object to onLstHeadingSelect()
        w = evt.widget
        w.config(bg="black")
        w.config(fg="white")
        lblText = w.cget("text")
        if lblText == " Single ":
            lblMulti.config(bg="white")
            lblMulti.config(fg="black")
            lstProperties.config(selectmode=SINGLE)
        elif lblText == " Multi ":
            lblSingle.config(bg="white")
            lblSingle.config(fg="black")
            lstProperties.config(selectmode=MULTIPLE)

    # Display Message Box function equivalant to VBA masgbox
    def msgbox (header, message):
        messagebox.showinfo(header, message)

    def displaySelectedPropertyHelpText(headingText, propertiesText):
        currElementNote = {}
        headingIndex = lstHeadings.curselection()[0]
        currElementNote = propertiesList[headingIndex]["notes"]
        elementIndex = lstProperties.curselection()[0]
        print("currElementNote", currElementNote)

        curr_Note = currElementNote[elementIndex]

        multilineHelp.configure(state='normal')
        multilineHelp.delete("1.0", tk.END)
        multilineHelp.insert(tk.INSERT, curr_Note)
        multilineHelp.configure(state='disabled')

    def onPropertiesElementSelection(index):
        propertiesText = lstProperties.get(index)
        headingText = lstHeadings.get(lstHeadings.curselection()[0])
        displaySelectedPropertyHelpText (headingText, propertiesText)

    # Called from lstHeading select Event with Index of selected element
    def onHeadingElementSelection(index):
        print("PropertyElement", propertiesList[index] )
        currElementDict = {}
        currElementDict = propertiesList[index]["element"]
        currPythonCall = pythonCallList[index]
        print("element", currElementDict)

        if isinstance(wdf, WordDocFile.WordDocFile ):
            result = getattr(wdf, currPythonCall)()
        else:
            messagebox.showinfo("Select Word Document", "Word document is not selected. Select Word Document.")
            result = ""

        multilineDocProperty.configure(state='normal')
        multilineDocProperty.delete("1.0", tk.END)
        multilineDocProperty.insert(tk.INSERT, result)
        multilineDocProperty.configure(state='disabled')

        # Adding Properties into listbox
        lstProperties.delete(0, END)
        for item in currElementDict:
            print("headingList item : ", item)
            lstProperties.insert(END, item)

    # Called when element in lstProperties listbox is selected
    def onLstPropertiesSelect(evt):
        # Note here that Tkinter passes an event object to onLstHeadingSelect()
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        onPropertiesElementSelection(index)

    # Called when element in lstHeading listbox is selected
    def onLstHeadingSelect(evt):
        # Note here that Tkinter passes an event object to onLstHeadingSelect()
        w = evt.widget
        index = int(w.curselection()[0])
        value = w.get(index)
        onHeadingElementSelection(index)

    # Not used. multilineContents is not used
    def displayFileContents(filename):
        file1 = open(filename, "r")
        data = file1.read()
        multilineContents.delete("1.0", tk.END)
        multilineContents.insert(tk.INSERT, data)
        file1.close()

    def displayTextInWordDocument():
        global wdf
        if isinstance(wdf, WordDocFile.WordDocFile ):
            docText = wdf.getDocumentText()
            # messagebox.showinfo("fullText", docText)
            multilineContents.delete("1.0", tk.END)
            multilineContents.insert(tk.INSERT, docText)
        else:
            multilineContents.delete("1.0", tk.END)
            multilineContents.insert(tk.INSERT, "")

    def btnSelectDocument_click():
        print("Select Word Document from local drive.")
        filename = askopenfilename()  # show an "Open" dialog box and return the path to the selected file
        print(filename)
        entryFileName.delete(0, tk.END)
        entryFileName.insert(1, filename)
        # displayFileContents(filename)
        global wdf
        wdf = WordDocFile.WordDocFile(filename)
        data = wdf.printDocumentPropertiesStdOut()
        # Displaying data in multilineDocProperty
        multilineDocProperty.configure(state='normal')
        multilineDocProperty.delete("1.0", tk.END)
        multilineDocProperty.insert(tk.INSERT, data)
        multilineDocProperty.configure(state='disabled')
        displayTextInWordDocument()


    window.geometry('950x750')
    window.title('Capture Word Document')

    frame = tk.Frame(master=window, width=1200, height=720, relief=tk.GROOVE, borderwidth=1)
    frame.pack()

    lblWordDocument = tk.Label(master=frame, text="Word Document :")
    lblWordDocument.place(x=10, y=10)

    entryFileName = tk.Entry(master=frame, width=100)
    entryFileName.place(x=110, y=10)

    # Adding Contents Label
    lblContents = tk.Label(master=frame, text="Contents :")
    lblContents.place(x=12, y=500)

    # Adding Multiline Textbox to Display Contents of File
    multilineContents = ScrolledText(master=frame, wrap=tk.WORD, width=145, height=12, padx=10, pady=10, font=("Tahoma", 8))
    multilineContents.place(x=12, y=520)

    fs = FrameworkSettings()

    cwd = os.getcwd()
    cwd = cwd + "\\" + "FrameworkForWordDocument.xlsx"
    # msgbox("cwd", cwd)

    fs.loadFrameworkSettings(cwd, "R")

    settingDict = {}
    settingDict = fs.processRowWiseElements()
    print("settingDict In mainModule() : ", settingDict)

    headingList = settingDict["Heading"]
    pythonCallList = settingDict["PythonCall"]
    propertiesList = settingDict["Details"]

    # create listbox Label
    lblHeading = tk.Label(master=frame, text="Headings :")
    lblHeading.place(x=12, y=40)

    # create Heading listbox control
    lstHeadings = Listbox(master=frame, height=10,
                      width=35,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstHeadings.bind('<<ListboxSelect>>', onLstHeadingSelect)
    lstHeadings.place(x=12, y=60)
    lstHeadings.delete(0, END)
    # Adding Headings into listbox
    for item in headingList:
        print("headingList item : ", item)
        lstHeadings.insert(END, item)

    # Setting Scrollbar to listbox .....NOT WORKING
    scrollbar = Scrollbar(master=lstHeadings)
    lstHeadings.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=lstHeadings.yview)

    # create Properties listbox Label
    lblProperties = tk.Label(master=frame, text="Properties :")
    lblProperties.place(x=250, y=40)

    lblSingle = tk.Label(master=frame, text=" Single ", bg='black', fg='yellow', underline=8, highlightbackground='green', borderwidth=1, relief="groove")
    lblSingle.place(x=450, y=40)
    lblSingle.bind("<Button-1>", setSingleSelectProperty)

    lblMulti = tk.Label(master=frame, text=" Multi ", bg='white', fg='black', underline=7, highlightbackground='green', borderwidth=1, relief="groove")
    lblMulti.place(x=500, y=40)
    lblMulti.bind("<Button-1>", setSingleSelectProperty)

    # create Properties listbox control
    lstProperties = Listbox(master=frame, height=10,
                        width=50,
                        bg="white",
                        activestyle='dotbox',
                        fg="black",
                        selectmode="multiple")

    lstVsb = tk.Scrollbar(frame, orient="vertical", command=lstProperties.yview)
    lstHsb = tk.Scrollbar(frame, orient="horizontal", command=lstProperties.xview)
    lstProperties.configure(yscrollcommand=lstVsb.set, xscrollcommand=lstHsb.set)

    lstProperties.config(selectmode=SINGLE)
    lstProperties.bind('<<ListboxSelect>>', onLstPropertiesSelect)

    lstProperties.place(x=250, y=60)
    lstProperties.delete(0, END)

    # Adding Multiline Help Textbox to Display Help Information
    # create Properties Description Label
    lblPropertyDesc = tk.Label(master=frame, text="Description :")
    lblPropertyDesc.place(x=570, y=40)

    multilineHelp = ScrolledText(master=frame, bg = '#ffffe6', fg = '#000000', wrap=tk.WORD,  width=45, height=10, padx=10, pady=10, font=("Tahoma",  10))
    multilineHelp.place(x=570, y=60)
    multilineHelp.configure(state='disabled')

    # Adding label and Textbox to display selected properties of Word Document
    lblDocumentProperty = tk.Label(master=frame, text="Selected Properties")
    lblDocumentProperty.place(x=12, y=250)

    multilineDocProperty = ScrolledText(master=frame, wrap=tk.WORD, bg = '#ffffe6', fg = '#000000',  width=125, height=12, padx=10, pady=10, font=("Tahoma",  10))
    multilineDocProperty.place(x=12, y=280)
    multilineDocProperty.configure(state='disabled')

    textVsb = tk.Scrollbar(frame, orient="vertical", command=multilineDocProperty.yview)
    textHsb = tk.Scrollbar(frame, orient="horizontal", command=multilineDocProperty.xview)
    multilineDocProperty.configure(yscrollcommand=textVsb.set, xscrollcommand=textHsb.set)

    # 'Adding Button to Select Document'
    btnSelectDocument = tk.Button(master=frame, text="Select Word Document", command=btnSelectDocument_click)
    btnSelectDocument.place(x=720, y=10)
    btnSelectDocument.bind("Click", btnSelectDocument_click)

    frame.place(x=10, y=10)
    lstHeadings.select_set(0)
    window.mainloop()


