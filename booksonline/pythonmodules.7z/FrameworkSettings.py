 # Framework Settings Class

from openpyxl import Workbook
from openpyxl import load_workbook

class FrameworkSettings:

    elements=tuple()
    elementProperties={}

    frameworkWb=Workbook()

    def __init__(self):
        pass

    def loadFrameworkSettings(self, filepathname, mode):
        self.filepathname=filepathname
        self.mode=mode
        print("read_Reposotory_Framework.....start")
        self.frameworkWb=load_workbook(filename=filepathname)
        print("frameworkWb sheetnames : ", self.frameworkWb.sheetnames)
        self.frameworksheet=self.frameworkWb.active
        print("frameworksheet : ", self.frameworksheet)

    # Generating Dictionary of FrameworkWord Setting
    def processRowWiseElements (self):
        print("----------------------------- Printing RowWise Data Start-----------------------------")
        address=list(self.frameworkWb.defined_names['frameworkWord'].destinations)
        print("address : ", address)            #  [('framework', '$C$2:$G$185')]
        # removing the $ from the address
        for sheetname, cellAddress in address:
            cellAddress=cellAddress.replace('$', '')

        worksheet=self.frameworkWb[sheetname]

        prevHeading=""
        currHeading=""
        prevPythonCall=""
        curr_PythonCall=""
        headingList=[]
        pythonCallList=[]
        detailsList=[]
        elementsList=[]
        formatList=[]
        methodList=[]
        notesList=[]

        # Dictionary for saving frameworkWord settings from Excel
        settingDict = {}
        thisDict = {}
        prevDict = {}
        prevHeading = ""
        prevPythonCall = ""
        for value in worksheet.iter_rows(min_row=3, min_col=3, max_row=185, max_col=8, values_only=True):
            print("value : " , value)
            t=value
            curr_heading=t[0] if t[0] != None else ""
            curr_element=t[1] if t[1] != None else ""
            curr_format=t[2] if t[2] != None else ""
            curr_method=t[3] if t[3] != None else ""
            curr_notes=t[4] if t[4] != None else ""
            curr_pythonCall=t[5] if t[5] != None else ""

            print("t[0] : ", t[0])
            print("t[1] : ", t[1])
            print("t[2] : ", t[2])
            print("t[3] : ", t[3])
            print("t[4] : ", t[4])
            print("t[5] : ", t[5])

            if prevHeading != curr_heading:
                #Start new collection of heading
                if prevHeading != "":
                    # Creating collection with key: prevHeading and Value: collection of Element, Format, Method, Notes
                    thisDict={}
                    prevDict={}
                    prevDict["element"]=elementsList
                    prevDict["format"]=formatList
                    prevDict["method"]=methodList
                    prevDict["notes"]=notesList
                    headingList.append(prevHeading)
                    pythonCallList.append(prevPythonCall)
                    detailsList.append(prevDict)

                    'Initializing the Tuples'
                    elementsList = []
                    formatList = []
                    methodList = []
                    notesList = []

                    prevHeading=curr_heading
                    prevPythonCall = curr_pythonCall

                    elementsList.append(curr_element)
                    formatList.append(curr_format)
                    methodList.append(curr_method)
                    notesList.append(curr_notes)

                elif prevHeading == "":    # very first iteration
                    headingList = []
                    pythonCallList = []
                    elementsList = []
                    formatList = []
                    methodList = []
                    notesList = []

                    prevHeading=curr_heading
                    prevPythonCall=curr_pythonCall

                    elementsList.append(curr_element)
                    formatList.append(curr_format)
                    methodList.append(curr_method)
                    notesList.append(curr_notes)
            else:
                prevHeading = curr_heading
                prevPythonCall = curr_pythonCall

                elementsList.append(curr_element)
                formatList.append(curr_format)
                methodList.append(curr_method)
                notesList.append(curr_notes)

        prevDict = {}
        prevDict["element"] = elementsList
        prevDict["format"] = formatList
        prevDict["method"] = methodList
        prevDict["notes"] = notesList

        headingList.append(prevHeading)
        pythonCallList.append(prevPythonCall)
        detailsList.append(prevDict)

        settingDict["Heading"] = headingList
        settingDict["PythonCall"] = pythonCallList
        settingDict["Details"] = detailsList

        print("settingDict : ", settingDict)
        print("len(headingList) : ", len(headingList))
        print("len(pythonCallList) : ", len(pythonCallList))
        print("len(detailsList) : ", len(detailsList))
        print("----------------------------- Printing RowWise Data End-----------------------------")
        return settingDict

    def __str__(self):
        return f"filepath: {self.filepathname} , mode : {self.mode} "
