import requests
from requests.auth import HTTPBasicAuth
import json
import os



class JiraRestCall:
    jServer = ""
    url = ""
    resUrl = ""
    headers = {"Accept": "application/json"}
    auth = ()

    def __init__(self, strUrl):
        self.url = strUrl

    def setJiraServer(self, jiraServer):
        self.jServer = jiraServer

    def setUrl(self, strUrl):
        self.url = strUrl

    def setAuth(self, userLogin, apiToken):
        self.auth = HTTPBasicAuth(userLogin, apiToken)

    def setHeader(self, reqHeaders):
        self.headers = reqHeaders

    # def setResource(self, resourceUrl):
    #     self.resUrl = resourceUrl

    def getResponse(self):
        print("inside getResponse: resUrl -> ", self.url)
        print("inside getResponse: headers -> ", self.headers)
        print("inside getResponse: auth -> ", self.auth)
        response = requests.request("GET", self.url, headers=self.headers, auth=self.auth)
        print("inside getResponse: response -> ", response.text)
        # responseText = json.dumps(json.loads(response.text), sort_keys=True, indent=4, seperators=(",", ": "))
        print("responseText : ", response.text)
        return response.text


# url = 'https://unity-central.atlassian.net/rest/api/2/issue/createmeta'
# auth = HTTPBasicAuth("rahul.varadkar@boardwalktech.com", "rawAAiz6NRFZWgoqlhfH6DA5")
# headers = {
#     "Accept": "application/json"
# }
# response = requests.request("GET", url, headers=headers, auth=auth)
# print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))

