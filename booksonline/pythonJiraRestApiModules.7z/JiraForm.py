import os
import tkinter as tk
from tkinter import messagebox, Frame, font
from tkinter.scrolledtext import ScrolledText
from tkinter import *
from FrameworkSettingsJiraApi import FrameworkSettingsJiraApi
from JiraRestCall import JiraRestCall
import json
import requests
from requests.auth import HTTPBasicAuth

window = tk.Tk()

entryRestApi = ()
multilineRestApiDesc = ()
entryJiraServer = ()
entryUserEmail = ()
entryApiToken = ()
multilineResponse = ()

settingDict = {}
jiraResourceList = []
apiSignatureList = []
apiDescriptionList = []


# Called from lstHeading select Event with Index of selected element
def onResourceElementSelection(index):
    global apiSignatureList, apiDescriptionList
    global entryRestApi, multilineRestApiDesc, multilineResponse
    global entryJiraServer, entryUserEmail, entryApiToken

    print("API Signature : ", apiSignatureList[index])
    print("API Description : ", apiDescriptionList[index])
    # messagebox.showinfo("API Signature : ", apiSignatureList[index])
    # messagebox.showinfo("API Description : ", apiDescriptionList[index])

    apiSignature = apiSignatureList[index]
    jiraServer = entryJiraServer.get()
    # messagebox.showinfo("entryJiraServer", entryJiraServer.get())
    # messagebox.showinfo("original", apiSignature)
    # messagebox.showinfo("replaced", apiSignature.replace("{JIRA_SERVER}", jiraServer))

    # Displaying corresponding API Signature and API Description
    entryRestApi.delete(0, END)
    entryRestApi.insert(END, apiSignature.replace("{JIRA_SERVER}", jiraServer))

    multilineRestApiDesc.configure(state='normal')
    multilineRestApiDesc.delete("1.0", tk.END)
    multilineRestApiDesc.insert(tk.INSERT, apiDescriptionList[index])
    multilineRestApiDesc.configure(state='disabled')

def btnCallJira_click():
    # messagebox.showinfo("btnCallJira_click", "")
    global entryJiraServer, entryUserEmail, entryApiToken, entryRestApi
    # messagebox.showinfo("entryRestApi", entryRestApi.get())

    jira = JiraRestCall(entryRestApi.get())
    jira.setUrl(entryRestApi.get())
    jira.setAuth(entryUserEmail.get(), entryApiToken.get())
    jira.setHeader({ "Accept": "application/json" })

    multilineResponse.configure(state='normal')
    multilineResponse.delete("1.0", tk.END)
    multilineResponse.insert(tk.INSERT, "")
    multilineResponse.configure(state='disabled')

    responseText = jira.getResponse()
    responseText = json.dumps(json.loads(responseText), sort_keys=True, indent=4, separators=(",", ": "))

    multilineResponse.configure(state='normal')
    multilineResponse.delete("1.0", tk.END)
    multilineResponse.insert(tk.INSERT, responseText)
    multilineResponse.configure(state='disabled')

    # url = 'https://unity-central.atlassian.net/rest/api/2/issue/createmeta'
    # url = 'https://unity-central.altassian.net/rest/api/2/project'


def onlstResourceSelect(evt):
    # Note here that Tkinter passes an event object to onlstResourceSelect()
    w = evt.widget
    index = int(w.curselection()[0])
    value = w.get(index)
    onResourceElementSelection(index)

def displayRestCallWindow():
    global entryJiraServer, entryUserEmail,  entryApiToken
    global settingDict
    global jiraResourceList, apiDescriptionList, apiSignatureList
    global multilineRestApiDesc, multilineResponse, entryRestApi

    window.geometry('1000x680')
    window.title('Capture data from JIRA')
    frame = tk.Frame(master=window, width=1200, height=720, relief=tk.GROOVE, borderwidth=1)
    frame.pack()

    # Jira URL label
    lblJiraURL = tk.Label(master=frame, text="Jira Server :")
    lblJiraURL.place(x=10, y=10)


    # Textbox to enter Jira Server url
    entryJiraServer = tk.Entry(master=frame, width=100)
    entryJiraServer.place(x=80, y=10)
    entryJiraServer.delete(0, tk.END)
    entryJiraServer.insert(1, "https://unity-central.atlassian.net")

    # Adding User Email Label
    lblUserEmail = tk.Label(master=frame, text="User Email :")
    lblUserEmail.place(x=10, y=35)

    # Textbox entry for User Email
    entryUserEmail = tk.Entry(master=frame, width=40)
    entryUserEmail.place(x=80, y=35)
    entryUserEmail.delete(0, tk.END)
    entryUserEmail.insert(1, "rahul.varadkar@boardwalktech.com")

    # Adding User Api Token
    lblApiToken = tk.Label(master=frame, text="Api Token :")
    lblApiToken.place(x=370, y=35)

    # Textbox entry for Api Token
    entryApiToken = tk.Entry(master=frame, width=40)
    entryApiToken.place(x=440, y=35)
    entryApiToken.delete(0, tk.END)
    entryApiToken.insert(1, "rawAAiz6NRFZWgoqlhfH6DA5")

    fs = FrameworkSettingsJiraApi()
    cwd = os.getcwd()
    cwd = cwd + "\\" + "FrameworkForJiraApi.xlsx"

    fs.loadFrameworkSettings(cwd, "R")

    settingDict = fs.processRowWiseElements()

    print("settingDict in module : ", settingDict)

    jiraResourceList = settingDict["JiraResource"]
    apiSignatureList = settingDict["ApiSignature"]
    apiDescriptionList = settingDict["ApiDescription"]

    # create Resources listbox Label
    lblResources = tk.Label(master=frame, text="Resources :")
    lblResources.place(x=12, y=65)

    # create Resources listbox control
    lstResources = Listbox(master=frame, height=10,
                      width=35,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstResources.bind('<<ListboxSelect>>', onlstResourceSelect)
    lstResources.place(x=12, y=90)
    lstResources.delete(0, END)

    # Adding Headings into listbox
    for item in jiraResourceList:
        print("jiraResourceList item : ", item)
        lstResources.insert(END, item)

    # Setting Scrollbar to listbox .....NOT WORKING
    scrollbar = Scrollbar(master=lstResources)
    lstResources.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=lstResources.yview)

    # create Rest API Call listbox Label
    lblRestApi = tk.Label(master=frame, text="Rest API Call :")
    lblRestApi.place(x=250, y=65)

    # 'Adding Button to Select Document'
    btnCallJira = tk.Button(master=frame, text="Call Jira Server", command=btnCallJira_click)
    btnCallJira.place(x=880, y=85)
    btnCallJira.bind("Click", btnCallJira_click)

    # create Rest Api Call listbox control
    entryRestApi = tk.Entry(master=frame, width=102)
    entryRestApi.place(x=250, y=90)
    entryRestApi.delete(0, END)

    # Adding Multiline Textbox to Display REST Api Information
    # create Properties Description Label
    lblRestApiDesc = tk.Label(master=frame, text="Api Description :")
    lblRestApiDesc.place(x=250, y=115)

    multilineRestApiDesc = ScrolledText(master=frame, bg = '#ffffe6', fg = '#000000', wrap=tk.WORD,  width=85, height=6, padx=10, pady=10, font=("Tahoma",  10))
    multilineRestApiDesc.place(x=250, y=140)
    multilineRestApiDesc.configure(state='disabled')

    # Adding Response Label
    lblResponse = tk.Label(master=frame, text="Response :")
    lblResponse.place(x=12, y=255)

    # Adding Multiline Textbox to Display Response from Jira Server
    multilineResponse = ScrolledText(master=frame, wrap=tk.WORD, width=145, height=25, padx=10, pady=10, font=("Tahoma", 8))
    multilineResponse.place(x=12, y=280)

    frame.place(x=10, y=10)
    window.mainloop()


displayRestCallWindow()