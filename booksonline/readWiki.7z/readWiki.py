import xml.etree.ElementTree as etree
import codecs
import csv
import time
import os
import re

PATH_WIKI_XML = 'D:\\WikiTaxi\\'
FILENAME_WIKI = 'simplewiki-20200501-pages-articles-multistream.xml'
FILENAME_ARTICLE = 'articles.csv'
FILENAME_REDIRECT = 'articles_redirect.csv'
FILENAME_TEMPLATE = 'articles_template.csv'
FILENAME_WIKITEXT = 'articles_text.csv'
ENCODING = 'utf-8'

#formatted time string

def hms_string(sec_elapsed):
    h = int(sec_elapsed/ (60 * 60))
    m = int((sec_elapsed % (60 * 60)) / 60)
    s = sec_elapsed % 60
    return "{}:{:>02}:{:>05.2f}".format(h, m, s)

def strip_tag_name(t):
    t = elem.tag
    idx = k = t.rfind("}")
    if idx != -1:
        t = t[idx + 1:]
    return t


pathWikiXML = os.path.join(PATH_WIKI_XML, FILENAME_WIKI)
pathArticles = os.path.join(PATH_WIKI_XML, FILENAME_ARTICLE)
pathArticlesRedirect = os.path.join(PATH_WIKI_XML, FILENAME_REDIRECT)
pathTemplateRedirect = os.path.join(PATH_WIKI_XML, FILENAME_TEMPLATE)
pathArticlesText = os.path.join(PATH_WIKI_XML, FILENAME_WIKITEXT)

page_ns = 0
totalCount = 0
articleCount = 0
redirectCount = 0
templateCount = 0
start_time = time.time()


with codecs.open(pathArticles, "w", ENCODING) as articlesFH, \
        codecs.open(pathArticlesRedirect, "w", ENCODING) as redirectFH, \
        codecs.open(pathTemplateRedirect, "w", ENCODING) as templateFH, \
        codecs.open(pathArticlesText, "w", ENCODING) as articlesAT:

    articlesWriter = csv.writer(articlesFH, quoting=csv.QUOTE_MINIMAL)
    redirectWriter = csv.writer(redirectFH, quoting=csv.QUOTE_MINIMAL)
    templateWriter = csv.writer(templateFH, quoting=csv.QUOTE_MINIMAL)
    articlesTextWriter = csv.writer(articlesAT, quoting=csv.QUOTE_MINIMAL)

    articlesWriter.writerow(['Page.id', 'Page.title', 'redirect.title'])
    redirectWriter.writerow(['Page.id', 'Page.title', 'redirect.title'])
    templateWriter.writerow(['Page.id', 'Page.title'])
    articlesTextWriter.writerow(['Page.id', 'Page.title', 'Page.ns', 'Revision.id', 'Revision.TimeStamp', 'Revision.Contributer.username', 'Revision.Contributer.id', 'Revision.parentid', 'Revision.monor', 'Revision.comment', 'Revision.model', 'Revision.format', 'Revision.text', 'Revision.sha1'])

    for event, elem in etree.iterparse(pathWikiXML, events=('start', 'end')):
        tname = strip_tag_name(elem.tag)
        # print(tname,  " [start] ----> ", tname)
        if event == 'start':
            if tname == 'page':
                page_title = ''
                page_id = -1
                redirect_title = ''
                inrevision = False
                incontributor = False
                page_ns = 0
                revision_id = -1
                revision_timestamp = ''
                revision_contributor_username = ''
                revision_contributor_userid = -1
                revision_parentid = -1
                revision_minor = ''
                revision_comment = ''
                revision_model = ''
                revision_format = ''
                revision_text = ''
                revision_sha1 = ''
            elif tname == 'revision':
                inrevision = True
            elif tname == 'contributor':
                incontributor = True

        elif event == 'end':
            # print(tname, " [end] ---->  : ", elem.text)
            # time.sleep(1)
            if tname == 'title' and not inrevision:
                page_title = elem.text
                # print("title: ", title)

            elif tname == 'id' and not inrevision:
                page_id = int(elem.text)
                # print("id: ", id)
            elif tname == 'id' and inrevision:
                revision_id = int(elem.text)
            elif tname == 'timestamp' and inrevision:
                revision_timestamp = elem.text
            elif tname == 'parentid' and inrevision:
                revision_parentid = int(elem.text)
            elif tname == 'minor' and inrevision:
                revision_minor = elem.text
            elif tname == 'comment' and inrevision:
                revision_comment = elem.text
            elif tname == 'model' and inrevision:
                revision_model = elem.text
            elif tname == 'format' and inrevision:
                revision_format = elem.text
            elif tname == 'sha1' and inrevision:
                revision_sha1 = elem.text
            elif tname == 'username' and inrevision and incontributor :
                revision_contributor_username = elem.text
            elif tname == 'id' and inrevision and incontributor:
                revision_contributor_userid = int(elem.text)
            elif tname == 'text' and inrevision:
                revision_text = ''
                revision_text = elem.text
                cleanText = ''
                cleanText = re.sub(r'[?|$|.|!|[|]|\{|\}|\"|\\n|\\r|,]', r'', str(revision_text))
                cleanText = cleanText.replace("]]", " ")
                cleanText = cleanText.replace("\n", " ")
                revision_text = cleanText
                # articlesTextWriter.writerow([id, title, cleanText])
                # print("text: ", text)


            elif tname == 'redirect':
                redirect_title = elem.attrib['title']
                # print("redirect_title: ", redirect_title)
            elif tname == 'ns':
                page_ns = int(elem.text)
                # print("ns: ", ns)
            elif tname == 'page':
                totalCount += 1
                # articlesTextWriter.writerow(['Page.id', 'Page.title', 'Page.ns', 'Revision.id', 'Revision.TimeStamp',
                #                              'Revision.Contributer.username', 'Revision.Contributer.id',
                #                              'Revision.parentid', 'Revision.monor', 'Revision.comment',
                #                              'Revision.model', 'Revision.format', 'Revision.text', 'Revision.sha1'])
                articlesTextWriter.writerow([page_id, page_title, page_ns, revision_id, revision_timestamp,
                                             revision_contributor_username, revision_contributor_userid,
                                             revision_parentid, revision_minor, revision_comment,
                                             revision_model , revision_format, revision_text , revision_sha1])


                if page_ns == 10:
                    templateCount += 1
                    templateWriter.writerow([page_id, page_title])
                elif len(redirect_title) > 0:
                    articleCount += 1
                    articlesWriter.writerow([page_id, page_title, redirect_title])
                else:
                    redirectCount += 1
                    redirectWriter.writerow([page_id, page_title, redirect_title])

                # if totalCount > 100000:
                #     break

                if totalCount > 1 and (totalCount % 100000) == 0:
                    print("{:,}".format(totalCount))

            elem.clear()

    elapsed_time = time.time() - start_time

    print("Total pages : {:,}".format(totalCount))
    print("Template pages: {:,}".format(templateCount))
    print("Article pages: {:,}".format(articleCount))
    print("Redirect pages: {:,}".format(redirectCount))
    print("Elapsed time: {}".format(hms_string(elapsed_time)))

