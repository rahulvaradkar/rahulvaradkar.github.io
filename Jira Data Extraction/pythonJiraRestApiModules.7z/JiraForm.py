import os
import tkinter as tk
import collections
import tkinter.font as tkFont
from tkinter import messagebox, Frame, font
from tkinter.scrolledtext import ScrolledText
from tkinter import *
import tkinter.ttk as ttk

from FrameworkSettingsJiraApi import FrameworkSettingsJiraApi
from JiraRestCall import JiraRestCall
import json
import requests
from requests.auth import HTTPBasicAuth

window = tk.Tk()

entryRestApi = ()
multilineRestApiDesc = ()
entryJiraServer = ()
entryUserEmail = ()
entryApiToken = ()
multilineResponse = ()
tree = ()

settingDict = {}
jiraResourceList = []
apiSignatureList = []
apiDescriptionList = []
col_headers = ["Name              ", "Value                                  ", "JsonPath                         "]
col_width = [200, 600, 600]
jsonTreeList = []


def btnClearList_click():
    global tree
    # for i in tree.get_children():         # this works
    #     tree.delete(i)
    tree.delete(*tree.get_children())


def btnDisplayElement_click():
    global tree
    # messagebox.showinfo("Clicked", "Clicked display element")
    curItem = tree.focus()
    print(tree.item(curItem))
    curRow = json.loads(json.dumps(tree.item(curItem)))
    if curRow["values"] == '':
        messagebox.showinfo("Select Element", "Element is not selected from the list.")
    else:
        messagebox.showinfo("Element ", "Name : " + str(curRow["values"][0]) + "\nValue : " + str(curRow["values"][1]) + "\nJsonPath : " + str(curRow["values"][2]))

# Get Path in JSON recursively
def get_paths(source):
    paths = []
    if isinstance(source, collections.MutableMapping):  # found a dict-like structure...
        for k, v in source.items():                     # iterate over it; Python 2.x: source.iteritems()
            paths.append([k])                           # add the current child path
            paths += [[k] + x for x in get_paths(v)]    # get sub-paths, extend with the current
    # else, check if a list-like structure, remove if you don't want list paths included
    elif isinstance(source, collections.Sequence) and not isinstance(source, str):
        #   Python 2.x: use basestring instead of str ^
        for i, v in enumerate(source):
            paths.append([i])
            paths += [[i] + x for x in get_paths(v)]    # get sub-paths, extend with the current
    return paths


def get_paths_list(source):
    paths = []
    if isinstance(source, collections.MutableMapping):  # found a dict-like structure...
        for k, v in source.items():                     # iterate over it; Python 2.x: source.iteritems()
            paths.append([k])                           # add the current child path
            paths += [[k] + x for x in get_paths_list(v)]    # get sub-paths, extend with the current
    # else, check if a list-like structure, remove if you don't want list paths included
    elif isinstance(source, collections.Sequence) and not isinstance(source, str):
        #   Python 2.x: use basestring instead of str ^
        for i, v in enumerate(source):
            if isinstance(v, collections.MutableMapping):
                paths.append([i])  # add the current child path
                for p, q in v.items():  # iterate over it; Python 2.x: source.iteritems()
                    paths.append([p])  # add the current child path
                    paths += [[p] + x for x in get_paths_list(q)]  # get sub-paths, extend with the current
            else:
                paths.append([i])
                paths += [[i] + x for x in get_paths_list(v)]    # get sub-paths, extend with the current

    return paths

def addTupleToList(name, value):
    # Tuple initializing
    t = (name, value)
    jsonTreeList.append(t)
    # print(jsonTreeList)
    # print("xxx ", name , " .... ", value)


#  Recursive function to extract Name and Value from JSON
# processJson = json.loads( json.dumps(storeData)  )
# func1(processJson)
def processJson(data):
    for key,value in data.items():
        # print (str(key)+'->'+str(value))
        addTupleToList(str(key), str(value))
        if type(value) == type(dict()):
            addTupleToList("--------------------", "---------------------")
            processJson(value)
            addTupleToList("--------------------", "---------------------")
        elif type(value) == type(list()):
            for val in value:
                addTupleToList(str(key), str(val))     #added by Rahul on 26-Sep-2020

                if type(val) == type(str()):
                    pass
                elif type(val) == type(list()):
                    pass
                else:
                    addTupleToList("--------------------", "---------------------")
                    processJson(val)
                    addTupleToList("--------------------", "---------------------")


def processJsonList(data):
    for key,value in data.items():
        # print (str(key)+'->'+str(value))
        addTupleToList(str(key), str(value))
        if type(value) == type(dict()):
            addTupleToList("--------------------", "---------------------")
            processJsonList(value)
            addTupleToList("--------------------", "---------------------")
        elif type(value) == type(list()):
            for val in value:

                if type(val) == type(str()):
                    pass
                elif type(val) == type(list()):
                    pass
                elif type(val) == type(dict()):
                    addTupleToList(str(key), str(val))  # added by Rahul on 26-Sep-2020
                    addTupleToList("--------------------", "---------------------")
                    processJsonList(val)
                    addTupleToList("--------------------", "---------------------")

# Called from lstHeading select Event with Index of selected element
def onResourceElementSelection(index):
    global apiSignatureList, apiDescriptionList
    global entryRestApi, multilineRestApiDesc, multilineResponse
    global entryJiraServer, entryUserEmail, entryApiToken

    print("API Signature : ", apiSignatureList[index])
    print("API Description : ", apiDescriptionList[index])

    apiSignature = apiSignatureList[index]
    jiraServer = entryJiraServer.get()

    # Displaying corresponding API Signature and API Description
    entryRestApi.delete(0, END)
    entryRestApi.insert(END, apiSignature.replace("{JIRA_SERVER}", jiraServer))

    multilineRestApiDesc.configure(state='normal')
    multilineRestApiDesc.delete("1.0", tk.END)
    multilineRestApiDesc.insert(tk.INSERT, apiDescriptionList[index])
    multilineRestApiDesc.configure(state='disabled')

def btnCallJira_click():
    # messagebox.showinfo("btnCallJira_click", "")
    global entryJiraServer, entryUserEmail, entryApiToken, entryRestApi, tree
    global jsonTreeList
    # messagebox.showinfo("entryRestApi", entryRestApi.get())

    jira = JiraRestCall(entryRestApi.get())
    jira.setUrl(entryRestApi.get())
    jira.setAuth(entryUserEmail.get(), entryApiToken.get())
    jira.setHeader({ "Accept": "application/json" })

    multilineResponse.configure(state='normal')
    multilineResponse.delete("1.0", tk.END)
    multilineResponse.insert(tk.INSERT, "")
    multilineResponse.configure(state='disabled')

    responseText = jira.getResponse()

    dataResponse = json.loads(responseText)

    # messagebox.showinfo(  "type(dataResponse)" , type(dataResponse))
    # if isinstance(dataResponse, list):
    #     messagebox.showinfo("response is list", "list")
    #
    # if isinstance(dataResponse, dict):
    #     messagebox.showinfo("response is dict", "dictionary")


    responseText = json.dumps(json.loads(responseText), sort_keys=True, indent=4, separators=(",", ": "))


    jsonTreeList = []

    if isinstance(dataResponse, dict):
        multilineResponse.configure(state='normal')
        multilineResponse.delete("1.0", tk.END)
        multilineResponse.insert(tk.INSERT, responseText)
        multilineResponse.configure(state='disabled')

        processJson(dataResponse)
        # Get all JSON Paths from the Response JSON
        print("dataResponse : ", dataResponse)
        paths = get_paths(dataResponse)

    if isinstance(dataResponse, list):
        fixedjson = '{ "data" : ' + json.dumps(dataResponse)  + " } "
        responseText = json.dumps(json.loads(fixedjson), sort_keys=True, indent=4, separators=(",", ": "))
        multilineResponse.configure(state='normal')
        multilineResponse.delete("1.0", tk.END)
        multilineResponse.insert(tk.INSERT, responseText)
        multilineResponse.configure(state='disabled')

        processJsonList( json.loads(fixedjson))
        jsonTreeList.pop(0)         # removing first element from list to match index of path and tree elements

        # Get all JSON Paths from the Response JSON
        paths = get_paths_list(dataResponse)


    # print("this is jsonTreeList.................")
    # icount=0
    # for key, value in jsonTreeList:
    #     print(icount, ' ',  key, ' -> ',  value)
    #     icount += 1

    # messagebox.showinfo("jsonTreeList.length ",  "jsonTreeList.length : " + str(icount))

    # icount=0
    # for x in range(len(paths)):
    #     print('path ', icount, ' ->', paths[x])
    #     icount += 1

    # messagebox.showinfo("path.length ",  len(paths))

    # ################################################333

    # Generating treeview list
    treeview = []
    thisline = []
    icount=0
    jcount=0
    for key, value in jsonTreeList:
        thisline = []
        print(icount, ' ',  key, ' -> ',  value)
        thisline.append(key)
        thisline.append(value)
        if key == '--------------------':
            thisline.append('None')
            # print(key,  ' ', value, ' ', 'None')
        else:
            print("jcount:", jcount)
            thisline.append(paths[jcount])
            # print(key,  ' ', value, ' ', paths[jcount])
            jcount += 1
        icount += 1
        # print("thisline", str(thisline))
        treeview.append(thisline)

    print("treeview-----------------")
    print(treeview)

    # Clearing all rows in tree
    tree.delete(*tree.get_children())

    # Adding tree from treeview, i.e. Name, Value , jSONPath
    for item in treeview:
        # print("item : ", item)
        tree.insert( '', 'end',  values=list(item))


def onlstResourceSelect(evt):
    # Note here that Tkinter passes an event object to onlstResourceSelect()
    w = evt.widget
    index = int(w.curselection()[0])
    value = w.get(index)
    onResourceElementSelection(index)


def sortby(tree, col, descending):
    """sort tree contents when a column header is clicked on"""
    # grab values to sort
    data = [(tree.set(child, col), child) \
        for child in tree.get_children('')]
    # if the data to be sorted is numeric change to float
    #data =  change_numeric(data)
    # now sort the data in place
    data.sort(reverse=descending)
    for ix, item in enumerate(data):
        tree.move(item[1], '', ix)
    # switch the heading so it will sort in the opposite direction
    tree.heading(col, command=lambda col=col: sortby(tree, col, int(not descending)))


def displayRestCallWindow():
    global entryJiraServer, entryUserEmail,  entryApiToken, tree
    global settingDict
    global jiraResourceList, apiDescriptionList, apiSignatureList
    global multilineRestApiDesc, multilineResponse, entryRestApi

    window.geometry('1380x710')
    window.title('Capture data from JIRA')
    frame = tk.Frame(master=window, width=700, height=690, relief=tk.GROOVE, borderwidth=1)
    frame.pack()

    treeframe = tk.Frame(master=window, width=640, height=690, relief=tk.GROOVE,  borderwidth=1)
    treeframe.pack()

    # Jira URL
    lblJiraURL = tk.Label(master=frame, text="Jira Server :")
    lblJiraURL.place(x=10, y=10)

    # Textbox to enter Jira Server url
    entryJiraServer = tk.Entry(master=frame, width=100)
    entryJiraServer.place(x=80, y=10)
    entryJiraServer.delete(0, tk.END)
    entryJiraServer.insert(1, "https://unity-central.atlassian.net")

    # Adding User Email Label
    lblUserEmail = tk.Label(master=frame, text="User Email :")
    lblUserEmail.place(x=10, y=35)

    # Textbox entry for User Email
    entryUserEmail = tk.Entry(master=frame, width=40)
    entryUserEmail.place(x=80, y=35)
    entryUserEmail.delete(0, tk.END)
    entryUserEmail.insert(1, "rahul.varadkar@boardwalktech.com")

    # Adding User Api Token
    lblApiToken = tk.Label(master=frame, text="Api Token :")
    lblApiToken.place(x=370, y=35)

    # Textbox entry for Api Token
    entryApiToken = tk.Entry(master=frame, width=40)
    entryApiToken.place(x=440, y=35)
    entryApiToken.delete(0, tk.END)
    entryApiToken.insert(1, "rawAAiz6NRFZWgoqlhfH6DA5")

    fs = FrameworkSettingsJiraApi()
    cwd = os.getcwd()
    cwd = cwd + "\\" + "FrameworkForJiraApi.xlsx"

    fs.loadFrameworkSettings(cwd, "R")

    settingDict = fs.processRowWiseElements()

    print("settingDict in module : ", settingDict)

    jiraResourceList = settingDict["JiraResource"]
    apiSignatureList = settingDict["ApiSignature"]
    apiDescriptionList = settingDict["ApiDescription"]

    # create Resources listbox Label
    lblResources = tk.Label(master=frame, text="Resources :")
    lblResources.place(x=12, y=65)

    # create Resources listbox control
    lstResources = Listbox(master=frame, height=10,
                      width=35,
                      bg="white",
                      activestyle='dotbox',
                      fg="black",
                      selectmode ="single",
                      exportselection=False)

    lstResources.bind('<<ListboxSelect>>', onlstResourceSelect)
    lstResources.place(x=12, y=90)
    lstResources.delete(0, END)

    # Adding Headings into listbox
    for item in jiraResourceList:
        print("jiraResourceList item : ", item)
        lstResources.insert(END, item)

    # Setting Scrollbar to listbox .....NOT WORKING
    scrollbar = Scrollbar(master=lstResources)
    lstResources.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=lstResources.yview)

    # create Rest API Call listbox Label
    lblRestApi = tk.Label(master=frame, text="Rest API Call :")
    lblRestApi.place(x=250, y=65)

    # 'Adding Button to Select Document'
    btnCallJira = tk.Button(master=frame, text="Call Jira Server", command=btnCallJira_click)
    btnCallJira.place(x=598, y=60)
    btnCallJira.bind("Click", btnCallJira_click)

    # create Rest Api Call listbox control
    entryRestApi = tk.Entry(master=frame, width=71)
    entryRestApi.place(x=250, y=90)
    entryRestApi.delete(0, END)

    # Adding Multiline Textbox to Display REST Api Information
    # create Properties Description Label
    lblRestApiDesc = tk.Label(master=frame, text="Api Description :")
    lblRestApiDesc.place(x=250, y=115)

    multilineRestApiDesc = ScrolledText(master=frame, bg = '#ffffe6', fg = '#000000', wrap=tk.WORD,  width=58, height=6, padx=10, pady=10, font=("Tahoma",  10))
    multilineRestApiDesc.place(x=250, y=140)
    multilineRestApiDesc.configure(state='disabled')

    #Adding treecontrol as listbox

    tree = ttk.Treeview(treeframe, height=30, columns=col_headers, show="headings")

    vsb = ttk.Scrollbar(orient="horizontal", command=tree.yview)
    hsb = ttk.Scrollbar(orient="vertical", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

    for col in col_headers:
        tree.heading(col, text=col.title(), command=lambda c=col: sortby(tree, c, 0) )
        tree.column(col, width=tkFont.Font().measure(col.title()))

    # tree.place(x=1000, y=20)
    tree.place(x=10, y=10)


    # 'Adding Button to Display Element'
    btnDisplayElement = tk.Button(master=treeframe, text="Display Element", command=btnDisplayElement_click)
    btnDisplayElement.place(x=10, y=640)
    btnDisplayElement.bind("Click", btnDisplayElement_click)

    # Adding Button to Clear List Element
    btnClearList = tk.Button(master=treeframe, text="Clear List", command=btnClearList_click)
    btnClearList.place(x=110, y=640)
    btnClearList.bind("Click", btnClearList_click)

    # Adding Response Label
    lblResponse = tk.Label(master=frame, text="Response :")
    lblResponse.place(x=12, y=255)

    # Adding Multiline Textbox to Display Response from Jira Server
    multilineResponse = ScrolledText(master=frame, wrap=tk.WORD, width=80, height=20, padx=10, pady=10, font=("Tahoma", 11))
    multilineResponse.place(x=12, y=280)

    frame.place(x=10, y=10)
    treeframe.place(x=725, y=10)
    window.mainloop()


displayRestCallWindow()