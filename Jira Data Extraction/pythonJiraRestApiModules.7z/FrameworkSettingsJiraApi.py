# Framework Settings Class for JIRA API

from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl import utils
import json

class FrameworkSettingsJiraApi:

    elements=tuple()
    elementProperties={}

    frameworkWb=Workbook()

    def __init__(self):
        pass

    def loadFrameworkSettings(self, filepathname, mode):
        self.filepathname=filepathname
        self.mode=mode
        print("read_Reposotory_Framework.....start")
        self.frameworkWb=load_workbook(filename=filepathname)
        print("frameworkWb sheetnames : ", self.frameworkWb.sheetnames)
        self.frameworksheet=self.frameworkWb.active
        print("frameworksheet : ", self.frameworksheet)

    def getMinMaxRowColumnOfNamedRange(self):
        address=list(self.frameworkWb.defined_names['frameworkJiraApi'].destinations)
        print("----address-------", address)
        print("address[0] : ", address[0])           # address[0] :  ('framework', '$C$3:$E$6')
        print("address[0][0] : ", address[0][0])     # address[0][0] :  framework
        print("address[0][1] : ", address[0][1])     # address[0][1] :  $C$3:$E$6
        print("address : ", address)            #  [('framework', '$C$3:$E$6')]
        # removing the $ from the address
        cellAdd  = ""
        shname = ""
        for sheetname, cellAddress in address:
            shname = sheetname
            cellAdd =cellAddress.replace('$', '')

        print(utils.cell.range_to_tuple(shname + "!" + cellAdd))
        tup = utils.cell.range_to_tuple(shname + "!" + cellAdd)
        print("tup[0]", tup[0])             # tup[0] framework
        print("tup[1]", tup[1])             # tup[1] (3, 2, 7, 185)
        print("tup[1][0]", tup[1][0])       # tup[1][0] 3
        print("tup[1][1]", tup[1][1])       # tup[1][1] 2
        print("tup[1][2]", tup[1][2])       # tup[1][2] 7
        print("tup[1][3]", tup[1][3])       # tup[1][3] 185
        return tup[1]

    # Generating Dictionary of FrameworkWord Setting
    def processRowWiseElements (self):
        print("----------------------------- Printing RowWise Data Start-----------------------------")
        address=list(self.frameworkWb.defined_names['frameworkJiraApi'].destinations)
        print("address : ", address)            #  [('framework', '$C$2:$G$185')]
        # removing the $ from the address
        for sheetname, cellAddress in address:
            cellAddress=cellAddress.replace('$', '')

        worksheet=self.frameworkWb[sheetname]

        jiraResourceList=[]
        apiSignatureList=[]
        descriptionList=[]

        # Dictionary for saving frameworkWord settings from Excel
        settingDict = {}

        tup = self.getMinMaxRowColumnOfNamedRange()
        print("tup :", tup)
        mnc = tup[0]
        mnr = tup[1]
        mxc = tup[2]
        mxr = tup[3]

        print("min_row=", mnr, " min_col=", mnc, " max_row=", mxr, " max_col=" , mxc)

        # for value in worksheet.iter_rows(min_row=mnr, max_row=mxr, min_col=mnc,  max_col=mxc, values_only=True):  errror
        # for value in worksheet.iter_rows(min_row=3, max_row=9, min_col=3, max_col=5, values_only=True): corrrect
        for value in worksheet.iter_rows(min_row=mnr, max_row=mxr, min_col=mnc, max_col=mxc, values_only=True):
            print("value : ", value)
            t=value
            print("t[0] : ", t[0])
            print("t[1] : ", t[1])
            print("t[2] : ", t[2])

            curr_resource = t[0] if t[0] != None else ""
            curr_apisign = t[1] if t[1] != None else ""
            curr_apidesc = t[2] if t[2] != None else ""

            jiraResourceList.append(curr_resource)
            apiSignatureList.append(curr_apisign)
            descriptionList.append(curr_apidesc)

        settingDict["JiraResource"] = jiraResourceList
        settingDict["ApiSignature"] = apiSignatureList
        settingDict["ApiDescription"] = descriptionList

        print("settingDict : ", settingDict)
        print("len(jiraResourceList) : ", len(jiraResourceList))
        print("len(apiSignatureList) : ", len(apiSignatureList))
        print("len(descriptionList) : ", len(descriptionList))
        print("----------------------------- Printing RowWise Data End-----------------------------")
        return settingDict

    def __str__(self):
        return f"filepath: {self.filepathname} , mode : {self.mode} "
